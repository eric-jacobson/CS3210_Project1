/* 
  stair is one block in Stairs assembly
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Stair extends Block {

  // texture info for the 6 faces---shared over all Stair blocks
  private static int[] texs = {5,6,5,6,5,6,5,6};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  private static double[] scales = {2,2,2,2,2,2};  // each kind of block has its own texture
                                               // scaling

  public static double typWidth=4, typThickness=1, typDepth=2;

  public Stair( Scanner input ) {
    super( input );  // get location and size
    kind = "Stair";
    textures = Stair.texs;
    texScales = Stair.scales;
  }

  public Stair( double ctrX, double ctrY, double ctrZ,
               double sizeX, double sizeY, double sizeZ ) {
    super( "Stair", ctrX, ctrY, ctrZ, sizeX, sizeY, sizeZ );
    textures = Stair.texs;
    texScales = Stair.scales;
  }

  // construct copy of other with center changed to (a,b,c)
  public Stair( Stair other, double a, double b, double c ) {
    super( "Stair", a, b, c, other.sx, other.sy, other.sz );
    textures = Stair.texs;
    texScales = Stair.scales;
  }

}// Stair
