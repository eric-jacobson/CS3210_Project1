/* 
  floor gives floors
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Floor extends Block {

  // texture info for the 6 faces---shared over all Floor blocks
  private static int[] texs = {7,7,7,7,7,7,7,7};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  private static double[] scales = {8,8,8,8,8,8};  // each kind of block has its own texture
                                               // scaling

  public static double typWidth=4, typLength=8, typHeight=1;

  public Floor( Scanner input ) {
    super( input );  // get location and size
    kind = "Floor";
    textures = Floor.texs;
    texScales = Floor.scales;
  }

  public Floor( double ctrX, double ctrY, double ctrZ,
               double sizeX, double sizeY, double sizeZ ) {
    super( "Floor", ctrX, ctrY, ctrZ, sizeX, sizeY, sizeZ );
    textures = Floor.texs;
    texScales = Floor.scales;
  }

  // construct copy of other with center changed to (a,b,c)
  public Floor( Floor other, double a, double b, double c ) {
    super( "Floor", a, b, c, other.sx, other.sy, other.sz );
    textures = Floor.texs;
    texScales = Floor.scales;
  }

}// Floor
