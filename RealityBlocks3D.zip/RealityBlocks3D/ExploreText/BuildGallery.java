/*
  build a texture that
  contains a bunch of
  symbols arranged in
  a "gallery" horizontally
  with a common baseline
  
  Such a texture can be
  used to draw individual
  chunks in OpenGL
*/

import java.awt.Font;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.FontMetrics;
import java.awt.RenderingHints;

import java.awt.GraphicsEnvironment;

public class BuildGallery {

   public static void main(String[] args) {

      GraphicsEnvironment graphicsEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
      String[] names = graphicsEnv.getAvailableFontFamilyNames();
      System.out.println("The " + names.length + " font family names are: ");
      for (int k=0; k<names.length; k++) {
         System.out.println("Name #" + k + ": " + names[k]);
      }

      Font font = new Font("Times New Roman", Font.PLAIN, 16);

      int imageWidth = 0;
      int imageHeight = 0;

      for (int i = 32; i < 256; i++) {
         System.out.println("Working on symbol " + i + ":" );
         if (i != 127) {
            char c = (char) i;
            BufferedImage ch = createCharImage(font, c, false);

            System.out.println("width is " + ch.getWidth() +
                               "    height is " + ch.getHeight() );

            imageWidth += ch.getWidth();
            imageHeight = Math.max(imageHeight, ch.getHeight());
          }
      }

      System.out.println("max height of any symbol is " + imageHeight );

   }// main

   private static BufferedImage createCharImage(Font font, char c, boolean antiAlias) {

        // Create temporary image to extract character size

        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        if (antiAlias) {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }
        g.setFont(font);
        FontMetrics metrics = g.getFontMetrics();
        g.dispose();

        // Get char charWidth and charHeight
        int charWidth = metrics.charWidth(c);
        int charHeight = metrics.getHeight();

        // Check if charWidth is 0
        if (charWidth == 0) {
            return null;
        }

        // Create image for holding the char
        image = new BufferedImage(charWidth, charHeight, BufferedImage.TYPE_INT_ARGB);
        g = image.createGraphics();
        if (antiAlias) {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        }
        g.setFont(font);
        g.setPaint(java.awt.Color.WHITE);
        g.drawString(String.valueOf(c), 0, metrics.getAscent());
        g.dispose();
        return image;
    }

}// BuildGallery
