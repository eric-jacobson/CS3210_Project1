import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Explore extends Basic {

   public static void main(String[] args) {
      Explore app = new Explore("See Fonts", 0, 0, 620, 650);
   }

   // instance variables

   private String all;
   private String[] rows;

   public Explore( String title, int ulx, int uly, int pw, int ph ) {
      super(title,ulx,uly,pw,ph);
      pads.add( new Sketchpad(10, 40, 600, 600, 0, 10, 0, Color.white ) );

      all = "";
      for (int k=32; k<256; k++) {   // for (int k=32; k<127; k++) {
         if (k != 127)
            all += (char) k;
      }

      rows = new String[all.length()/10 + 1];

      for (int k=0; k<rows.length; k++) {
         rows[k] = "";
      }

      int row = 0;
      int col = 0;
      int k=0;
   
      while (k < all.length()) {
         rows[row] += all.charAt(k);
         k++;
         col++;
         if (col == 10) {
            row++;
            col = 0;
         }
      }

      super.start();
   }

   public synchronized void step() {

      Sketchpad pad = pads.get(0);
      pad.activate();

      pad.setFont("Wingdings2",Font.PLAIN, 16);

      pad.setColor(Color.red);
      
      for (int row=0; row<rows.length; row++) {
         pad.drawText(row + " " + rows[row],0.1, 9.5-row/2.0);
      }
      
      

   }

   public synchronized void keyPressed(KeyEvent e) {

     int code = e.getKeyCode();

   }// keyPressed

   public synchronized void mousePressed(MouseEvent e) {
   }// mousePressed

}// Explore
