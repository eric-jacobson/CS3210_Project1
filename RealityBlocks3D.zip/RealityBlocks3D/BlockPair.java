/* a BlockPair
   is simply two blocks

   (typically used for
    noting a pair of blocks
   that
   have been noted as having
   their swept volumes touch 
   a common cell
   or have collided)
*/

public class BlockPair {

   public Block first;
   public Block second;

   public BlockPair( Block a, Block b ) {
      first = a;
      second = b;
   }

   public boolean equals( Block a, Block b ) {
      return (first==a && second==b) || (first==b && second==a);
   }

   public String toString() {
      return "(" + first.getId() + "," + second.getId() + ")";
   }

}
