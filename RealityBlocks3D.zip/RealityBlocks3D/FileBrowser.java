import javax.swing.*;
import java.io.*;

public class FileBrowser
{
  private JFileChooser fileChooser;

  // create file chooser whose starting path, from
  // current directory, is given
  public FileBrowser( String dir )
  {
    fileChooser = null;

    try{
      File file = new File( dir );
      String path = file.getCanonicalPath();
      fileChooser = new JFileChooser( file.getCanonicalPath() );
    }
    catch(Exception e)
    {
      System.out.println("Could not make a file chooser with directory ["
                            + dir + "]");
      System.exit(1);
    }
  }

  // utility to select a file from which to read or write
  public String chooseFile( boolean doRead )
  {
    int code;
    if( doRead )
      code = fileChooser.showOpenDialog( null );
    else
      code = fileChooser.showSaveDialog( null );
  
    if( code == JFileChooser.APPROVE_OPTION )
    {
      File file = fileChooser.getSelectedFile();
      return file.getAbsolutePath();
    }
    else
    {
      return "";
    }
  }

}
