/* 
  wall is inert, used for
  walls, window frames, door frames
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Wall extends Block {

  // texture info for the 6 faces---shared over all Wall blocks
  private static int[] texs = {3,4,3,4,3,4};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  private static double[] scales = {8,8,8,8,8,8};  // each kind of block has its own texture
                                               // scaling

  public static double typWidth=4, typThickness=1, typHeight=12;

  public Wall( Scanner input ) {
    super( input );  // get location and size
    kind = "Wall";
    textures = Wall.texs;
    texScales = Wall.scales;
  }

  public Wall( double ctrX, double ctrY, double ctrZ, double sizeX, double sizeY, double sizeZ ) {
    super( "Wall", ctrX, ctrY, ctrZ, sizeX, sizeY, sizeZ );
    textures = Wall.texs;
    texScales = Wall.scales;
  }

  // construct copy of other with center changed to (a,b,c)
  public Wall( Wall other, double a, double b, double c ) {
    super( "Wall", a, b, c, other.sx, other.sy, other.sz );
    textures = Wall.texs;
    texScales = Wall.scales;
  }

}// Wall
