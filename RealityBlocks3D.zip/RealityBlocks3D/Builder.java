/*  
   Interactively build a game world with blocks
*/

import static org.lwjgl.glfw.GLFW.*;  // for key codes

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;

public class Builder extends Basic
{
  private final static int SPACE = 30;

  private final static boolean debug = false;

  public static double WORLDSIZE;   // world is a cube with this side length

  public static void main(String[] args)
  {
    if( args.length != 1 ){
      System.out.println("Usage:  j Builder <world file name>");
      System.exit(1);
    }

    // this app uses two square view areas
    final int windowHeight = 750;
    Builder app = new Builder( "World Builder", 30, 
                               2*windowHeight+SPACE, windowHeight, 30, args[0] );

    app.start();

  }// main

  // instance variables 

  private String worldFileName;
  private Cursor cursor;

  private boolean attached;  // want cursor attached to current
  private Assembly current;  // if attached is not null

  // rather silly variables used to read from input file before
  // OpenGL context is available, used only in init to init cameras
  private double[] camX, camY, camZ, camAzi, camAlt;

  private final static int NUMCAMS = 6; // probably will never change, but might
  private Camera[] camera;
  private int curCam;

  private Camera mapCam;

  // perm is the assemblies that
  // can't be attached to the cursor,
  // editable is the ones that can be
  private ArrayList<Assembly> perm, editable;

  private Soups permSoups, editableSoups, cursorSoups, cameraSoups;

  private boolean flyingCameras;

  private boolean showInfo;

  // construct basic application with given title, pixel width and height
  // of drawing area, frames per second, and name of world data file
  public Builder( String appTitle, int windowShift, int pw, int ph, int fps,
                    String worldFile )
  {
    super( appTitle, windowShift, pw, ph, (long) ((1.0/fps)*1000000000) );

    worldFileName = worldFile;

    try{

      Pic.init();      // load all the textures
      Util.init();     // set up single large buffer for soup use

      Scanner input = new Scanner( new File( worldFile ) );

      WORLDSIZE = input.nextDouble();    // get world cube side length from file
      input.nextLine();  // toss comment

      // get the camera data from input file
      camX = new double[NUMCAMS];
      camY = new double[NUMCAMS];
      camZ = new double[NUMCAMS];
      camAzi = new double[NUMCAMS];
      camAlt = new double[NUMCAMS];

      for (int k=0; k<NUMCAMS; k++) {
         camX[k] = input.nextDouble();
         camY[k] = input.nextDouble();
         camZ[k] = input.nextDouble();
         camAzi[k] = input.nextDouble();
         camAlt[k] = input.nextDouble();
         input.nextLine();  // finish line for a camera
      }

      // get the cursor data from input file
      cursor = new Cursor( input );

      attached = false;

      // note starting point for identifiers of new assemblies
      // (is simply one past the last one used in the input file)
      Assembly.setCurrentId( input.nextInt() );  input.nextLine();

      input.nextLine();  // toss the ---- separator line

      // make empty list of permanent assemblies, ready to load
      perm = new ArrayList<Assembly>();

      // load permanent assemblies from world file
      int numPerm = input.nextInt();  input.nextLine();
      for( int k=0; k<numPerm; k++ ) {
        Assembly a = Assembly.build( input );
        perm.add( a ); 
      }

      // now load the editable assemblies
      editable = new ArrayList<Assembly>();

      int numEditable = input.nextInt();  input.nextLine();
      for( int k=0; k<numEditable; k++ ) {
        Assembly a = Assembly.build( input );
        editable.add( a ); 
      }

      showInfo = true;

    }// construct world from data file

    catch(Exception e){
      System.out.println("Something went wrong loading from file [" + 
                          worldFile + "]");
      e.printStackTrace();
      System.exit(1);
    }

  }

  // save all assemblies to selected file
  private void save() {
    try {
      PrintWriter out = new PrintWriter( new File( worldFileName ) );

      out.println( WORLDSIZE + "       world size" );
      for (int k=0; k<NUMCAMS; k++) {
         out.println( camera[k].getUserInfo() );
      }
      out.println( cursor.getLocString() );

      out.println( Assembly.getCurrentId() );

      out.println("------------------------------\n");

      out.println( perm.size() + "        number of permanent world assemblies\n");

      // save permanent assemblies
      for( int k=0; k<perm.size(); k++ ) {
        perm.get( k ).save( out );
      }

      out.println("\n" + editable.size() + 
                  "      number of editable assemblies\n");

      // save editable assemblies
      for( int k=0; k<editable.size(); k++ ) {
        editable.get( k ).save( out );
      }

      out.close();

    }
    catch(Exception e) {
      System.out.println("Something went wrong saving to file [" + 
                          worldFileName + "]");
      e.printStackTrace();
      System.exit(1);
    }
  }

  protected void init()
  {
    OpenGL.init();
    OpenGL.useRegularProgram();

    // activate all the textures
    for( int k=0; k<Pic.size(); k++ ){
      OpenGL.loadTexture( Pic.get(k) );
      System.out.println("activated texture number " + k );
    }

    OpenGL.setBackColor( 0, 0, 0 );

    // initialize all 6 cameras
    camera = new Camera[6];
    curCam = 0;
    for (int k=0; k<NUMCAMS; k++) {
       camera[k] = new Camera( true, k, 0, 0, 
                   (getPixelWidth()-SPACE)/2, getPixelHeight(),  // viewport within pixel grid
                         -1., 1., -1, 1, 4, 1000,  // frustum (camera shape)
                          camX[k], camY[k], camZ[k],           // eye point
                          camAzi[k], camAlt[k] );           // azimuth, altitude
    }

    mapCam = new Camera( false, -1, SPACE + (getPixelWidth()-SPACE)/2, 0,
                             (getPixelWidth()-SPACE)/2, getPixelHeight(),
                             0, WORLDSIZE, 0, WORLDSIZE, -WORLDSIZE+5, 5,
                             0, 0, 0,
                             0, 0 );
 
    flyingCameras = true;  // begin with flying cameras

    // set up fixed for display once and for all
    permSoups = new Soups( Pic.size() );
    permSoups.addAll( perm );
    permSoups.sortByTexture();

    // System.out.println("finished creating the permSoups");

  }

  // update view matrices based on eye, angles
  private void updateView(){
     for (int k=0; k<6; k++) {
        camera[k].updateView();
     }
  }

  private static double amount = 1;  // distance to move per step

  private static int camAziAmount = 3;
  private static int camAltAmount = 3;

  // remember previous assembly of each kind
  private Assembly prevWall, prevFloor, prevStairs, prevHole, prevDoor,
                   prevMine;

  private boolean isCreationKey( int code, int mods ) {
    return (code == GLFW_KEY_W && mods == 0) ||   // w for wall
           (code == GLFW_KEY_F && mods == 0) ||   // f for floor
           (code == GLFW_KEY_S && mods == 0) ||   // s for stairs
           (code == GLFW_KEY_H && mods == 0) ||   // h for hole
           (code == GLFW_KEY_M && mods == 0) ||   // m for mine
           (code == GLFW_KEY_D && mods == 0);     // d for door
  }

  private void createAtCursor( int code, int mods ) {

    if( code == GLFW_KEY_W && mods == 0 ){// w for wall
      // create a new assembly, copy from previous if is one,
      //  at the cursor and note it
      if( prevWall != null ) {// build copy of previous assembly
        prevWall = new Single( prevWall, cursor.getX(), cursor.getY(), cursor.getZ() );
      }
      else {// build default wall at cursor
        prevWall = new Single( new Wall( cursor.getX(), cursor.getY(), cursor.getZ(), 
                                         Wall.typWidth, Wall.typThickness, Wall.typHeight ) );
      }

      attached = true;
      current = prevWall;
      editable.add( prevWall );
    }// w

    else if( code == GLFW_KEY_F && mods == 0 ){// f for floor
      // create a new assembly, copy from previous if is one,
      //  at the cursor and note it
      if( prevFloor != null ) {// build copy of previous assembly
        prevFloor = new Single( prevFloor, cursor.getX(), cursor.getY(), cursor.getZ() );
      }
      else {// build default floor at cursor
        prevFloor = new Single( new Floor( cursor.getX(), cursor.getY(), cursor.getZ(),
                                           Floor.typWidth, Floor.typLength, Floor.typHeight ) );
      }

      attached = true;
      current = prevFloor;
      editable.add( prevFloor );
    }// f

    else if( code == GLFW_KEY_M && mods == 0 ){// m for mine
      // create a new assembly, copy from previous if is one,
      //  at the cursor and note it
      if( prevMine != null ) {// build copy of previous assembly
        prevMine = new Single( prevMine, cursor.getX(), cursor.getY(), cursor.getZ() );
      }
      else {// build default mine at cursor
        prevMine = new Single( new Mine( cursor.getX(), cursor.getY(), cursor.getZ(),
                                           Mine.typWidth, Mine.typLength, Mine.typHeight ) );
      }

      attached = true;
      current = prevMine;
      editable.add( prevMine );
    }// m

    else if( code == GLFW_KEY_S && mods == 0 ){// s for stairs
      // create a new assembly, copy from previous if is one,
      //  at the cursor and note it
      if( prevStairs != null ) {// build copy of previous assembly
        prevStairs = new Stairs( prevStairs, cursor.getX(), cursor.getY(), cursor.getZ() );
      }
      else {// build default stairs at cursor
        prevStairs = new Stairs( cursor.getX(), cursor.getY(), cursor.getZ() );
      }

      attached = true;
      current = prevStairs;
      editable.add( prevStairs );
    }// s

    else if( code == GLFW_KEY_H && mods == 0 ){// h for hole
      // create a new assembly, copy from previous if is one,
      //  at the cursor and note it
      if( prevHole != null ) {// build copy of previous assembly
        prevHole = new Hole( prevHole, cursor.getX(), cursor.getY(), cursor.getZ() );
      }
      else {// build default hole at cursor
        prevHole = new Hole( cursor.getX(), cursor.getY(), cursor.getZ() );
      }

      attached = true;
      current = prevHole;
      editable.add( prevHole );
    }// h

   else if( code == GLFW_KEY_D && mods == 0 ){// d for door
      // create a new assembly, copy from previous if is one,
      //  at the cursor and note it
      if( prevDoor != null ) {// build copy of previous assembly
        prevDoor = new DoorFrame( prevDoor, cursor.getX(), cursor.getY(), cursor.getZ() );
      }
      else {// build default door at cursor
        prevDoor = new DoorFrame( cursor.getX(), cursor.getY(), cursor.getZ() );
      }

      attached = true;
      current = prevDoor;
      editable.add( prevDoor );
    }// h

  }// createAtCursor

  private boolean isMoveKey( int code, int mods ) {
    return (code == GLFW_KEY_LEFT  && mods == 0) ||
           (code == GLFW_KEY_RIGHT  && mods == 0) ||
           (code == GLFW_KEY_DOWN  && mods == 0) ||
           (code == GLFW_KEY_UP  && mods == 0) ||
           ( (code == GLFW_KEY_PAGE_DOWN || code==GLFW_KEY_9)  && mods == 0) ||
           ( (code == GLFW_KEY_PAGE_UP || code==GLFW_KEY_0)  && mods == 0);
  }

  private boolean isBlockEditKey( int code, int mods ) {
     return (code == GLFW_KEY_MINUS && mods == 0 ) ||      // rotate the block
            ( code == GLFW_KEY_EQUAL && mods == 0 ) ||

            ( code == GLFW_KEY_LEFT && mods == 1 ) ||      // resize the block
            ( code == GLFW_KEY_RIGHT && mods == 1 ) ||
            ( code == GLFW_KEY_DOWN && mods == 1 ) ||
            ( code == GLFW_KEY_UP && mods == 1 ) ||
            ( code == GLFW_KEY_PAGE_DOWN && mods == 1 ) ||
            ( code == GLFW_KEY_PAGE_UP && mods == 1 ) ||

            ( code == GLFW_KEY_L && mods == 1 ) ||        // edit inner hole
            ( code == GLFW_KEY_R && mods == 1 ) ||
            ( code == GLFW_KEY_D && mods == 1 ) ||
            ( code == GLFW_KEY_U && mods == 1 ) ||
            ( code == GLFW_KEY_N && mods == 1 ) ||
            ( code == GLFW_KEY_W && mods == 1 ) ||
            ( code == GLFW_KEY_S && mods == 1 ) ||
            ( code == GLFW_KEY_T && mods == 1 ) ||

            ( code == GLFW_KEY_F && mods == 1 ) ||       // edit number of stairs
            ( code == GLFW_KEY_M && mods == 1 );
  }

  private void moveCursor( int code, int mods ) {
    if( code == GLFW_KEY_LEFT && mods == 0 )    cursor.move( -amount, 0, 0 );
    else if( code == GLFW_KEY_RIGHT  && mods == 0 )  cursor.move( amount, 0, 0 );
    else if( code == GLFW_KEY_DOWN  && mods == 0 )  cursor.move( 0, -amount, 0 );
    else if( code == GLFW_KEY_UP  && mods == 0 )  cursor.move( 0, amount, 0 );
    else if( code == GLFW_KEY_PAGE_DOWN  && mods == 0 )  cursor.move( 0, 0, -amount );
    else if( code == GLFW_KEY_PAGE_UP  && mods == 0 )  cursor.move( 0, 0, amount );
  }

   // see if cursor is touching an assembly, and
   // if so attach to it
   // and return index in editable for some purposes
   public int tryToAttach() {

      int index = -1;

      if ( attached && current != null ) {// already attached
         // return index of guy already attached
         for (int k=0; k<editable.size() && index < 0; k++ ) {
            if (editable.get(k) == current ) {
               index = k;
            }
         }
      }
      else {// not attached, search for touch

         // see if touching an assembly and grab it
         index = findAssemblyTouching( editable, 
                                            cursor.getX(), cursor.getY(), cursor.getZ() );
         if ( index >= 0 ) {// found one touching
            current = editable.get( index );
            cursor.moveWith( current );  // adjust cursor location to center of current
            attached = true;
         }
         else {// cursor not touching anybody
            current = null;  // but leave attached unchanged
         }

      }

System.out.println("tryToAttach, before exit with index = " + index + " current = " +
                     current );

      return index;

   }// tryToAttach

  protected void processInputs()
  {
    // process all waiting input events
    while( InputInfo.size() > 0 ) {

      InputInfo info = InputInfo.get();

      showInfo = true;  // note processed at least one input event so display info

      if( info.kind == 'k' && (info.action == GLFW_PRESS || 
                               info.action == GLFW_REPEAT) ) {

        int code = info.code, mods = info.mods;
         System.out.println("code: " + code + " mods: " + mods );

        if( code == GLFW_KEY_COMMA && mods == 0 ) {// halve amount
          amount /= 2;
        }
        else if( code == GLFW_KEY_PERIOD ) {// double amount
          amount *= 2;
        }
  
        else if (code == GLFW_KEY_KP_0 ) {// toggle flying cameras
           flyingCameras = ! flyingCameras;
        }

        // select current camera
        else if( GLFW_KEY_1 <= code && code <= GLFW_KEY_6 ) {
          curCam = code - GLFW_KEY_1;  // will be 0..5 in camera array
        }

        else if( code == GLFW_KEY_GRAVE_ACCENT && mods == 1 ) {// ~ key
          save();
          System.exit(0);
        }

        // if attached drop current and become unattached,
        // if not attached, try for current and become attached
        else if( code == GLFW_KEY_ESCAPE ) {// esc toggles attachment
           if ( attached ) {
              attached = false; // don't want to be attached
              current = null;   // drop it
           }
           else {
 
              attached = true;  // want to be attached
                                // even if grab fails
              tryToAttach();
           }
        }// esc

        // camera control keys on the numeric keypad
        else if ( GLFW_KEY_KP_1 <= code && code <= GLFW_KEY_KP_9 ) { 
           camera[curCam].moveOrFly(code, mods, amount, 
                                    camAziAmount, camAltAmount,
                                    flyingCameras);
        }

        // creation keys (w, f, s, h, d) always create a block at cursor
        // and attach the new block to the cursor, doesn't matter
        // whether previously attached
        else if ( isCreationKey( code, mods ) ) {
           createAtCursor( code, mods );
        }

        // move cursor and attached block if any
        else if ( isMoveKey( code, mods ) ) {
           
           moveCursor( code, mods );  // move cursor for sure

           if ( current != null ) {// and move attached assembly
              if ( code == GLFW_KEY_LEFT && mods == 0 )    current.move( -amount, 0, 0 );
                 else if( code == GLFW_KEY_RIGHT  && mods == 0 )  current.move( amount, 0, 0 );
                 else if( code == GLFW_KEY_DOWN  && mods == 0 )  current.move( 0, -amount, 0 );
                 else if( code == GLFW_KEY_UP  && mods == 0 )  current.move( 0, amount, 0 );
                 else if( code == GLFW_KEY_PAGE_DOWN && mods == 0 )  current.move( 0, 0, -amount );
                 else if( code == GLFW_KEY_PAGE_UP && mods == 0 )  current.move( 0, 0, amount );
           }

        }// move key

        else if ( isBlockEditKey( code, mods ) ) {// edit attached block if any

           tryToAttach();  // if use hits one of these keys, thinks cursor is there

           if ( current != null ) {

              if ( code == GLFW_KEY_MINUS && mods == 0 )
                 current.rotate( 1 );
              else if( code == GLFW_KEY_EQUAL && mods == 0 )
                 current.rotate( -1 );
   
              else if( code == GLFW_KEY_LEFT && mods == 1 )
                 current.resize( -amount, 0, 0 );
              else if( code == GLFW_KEY_RIGHT && mods == 1 )
                 current.resize( amount, 0, 0 );
              else if( code == GLFW_KEY_DOWN && mods == 1 )
                 current.resize( 0, -amount, 0 );
              else if( code == GLFW_KEY_UP && mods == 1 )
                 current.resize( 0, amount, 0 );
              else if( (code == GLFW_KEY_PAGE_DOWN || code==GLFW_KEY_9) && mods == 1 )
                 current.resize( 0, 0, -amount );
              else if( (code == GLFW_KEY_PAGE_UP || code==GLFW_KEY_0) && mods == 1 )
                 current.resize( 0, 0, amount );
  
              else if( code == GLFW_KEY_L && mods == 1 )
                 current.moveInner( -amount, 0, 0 );
              else if( code == GLFW_KEY_R && mods == 1 )
                 current.moveInner( amount, 0, 0 );
              else if( code == GLFW_KEY_D && mods == 1 )
                 current.moveInner( 0,0, -amount );
              else if( code == GLFW_KEY_U && mods == 1 )
                 current.moveInner( 0,0, amount );
              else if( code == GLFW_KEY_N && mods == 1 )
                 current.resizeInner( -amount, 0 );
              else if( code == GLFW_KEY_W && mods == 1 )
                 current.resizeInner( amount, 0 );
              else if( code == GLFW_KEY_S && mods == 1 )
                 current.resizeInner( 0, -amount );
              else if( code == GLFW_KEY_T && mods == 1 )
                 current.resizeInner( 0, amount );
              else if( code == GLFW_KEY_F && mods == 1 )
                 current.specialChangeInner( "fewer" );
              else if( code == GLFW_KEY_M && mods == 1 )
                 current.specialChangeInner( "more" );

           }// have a current

        }// block edit key

        else if( code == GLFW_KEY_K && mods == 0 ) {// k for kill
           int index = tryToAttach();  // user thinks cursor is attached so grab it
           if ( current != null ) {//have an assembly to kill
              editable.remove( index );
              current = null;
           }
        }

        else if( code == GLFW_KEY_X && mods == 0 ) {// x for xerox

           tryToAttach();  // if want to make copy, user thinks somebody's attached

           if ( current != null ) {
              // make copy of current assembly

              if( current.getKind().equals("single") ) {
                current = new Single( current, current.getX(), current.getY(), current.getZ() );
              }
              else if( current.getKind().equals("hole") ) {
                current = new Hole( current, current.getX(), current.getY(), current.getZ() );
              }
              else if( current.getKind().equals("door") ) {
                current = new DoorFrame( current, current.getX(), current.getY(), current.getZ() );
              }
              else if( current.getKind().equals("stairs") ) {
                current = new Stairs( current, current.getX(), current.getY(), current.getZ() );
              }
              else {
                System.out.println("programming error in xerox");
                System.exit(1);
              }

              editable.add( current );
           }

        }// xerox
     
    }// input event is a key

    else if ( info.kind == 'm' ) {// mouse moved
     }

    else if( info.kind == 'b' ) {
       // button action

        if( info.code==0 && info.action==1 && info.mods==0 ) {// left button release with no shifting

          // move cursor to assembly pointed at by the mouse release

          // System.out.println("mouse release at " + getMouseX() + " " + getMouseY() );
          double pw = (getPixelWidth()-SPACE)/2, ph = getPixelHeight();

          double px = ( 2*getMouseX() - pw ) / pw;
          double py = ( ph - 2*getMouseY() ) / ph;

          // compute point in 3D space corresponding to mouse click
          Triple toCenter = camera[curCam].getDirection();  // unit vector from camera location 
                                                            // to center of view plane
          Triple right =  toCenter.crossProduct( Triple.zAxis );
          // had this error---right is not of length 1!
          right = right.normalized();
          Triple up = right.crossProduct( toCenter ); 
         
          // adjust lengths of right and up to match 3:4 aspect ratio of view rectangle
          //  no---I changed the ratio to square --- right = right.scalarProduct( 4.0/3 );
          // length 1 for up is correct

          // build center point on view rectangle
          Triple eye = camera[curCam].getLocation();
          Triple center = Triple.linearComb( 1.0, eye, 4.0, toCenter );
          // hit point is center + px*right + py*up
          Triple hitPoint = Triple.linearComb( 1.0, center, px, right, py, up );

          // now cast ray from eye to hitPoint, find first in editable, if any, that
          // the ray hits

          int victim = findFirstAssemblyHitByRay( eye, hitPoint );

          // move cursor to reference point of the hit assembly

          if( victim != -1 ) {// hit an editable assembly
            Assembly a = editable.get(victim);
            cursor.moveWith( a );

            attached = true;  // obviously wanted to be attached
            current = a;

          }// hit an editable assembly

        }// release of left button
        
      }// 'b' action

    }// loop to process all input events

  }// processInputs

  // return index of first editable assembly (if any)
  // that is hit by ray from eye to hitPoint
  private int findFirstAssemblyHitByRay( Triple a, Triple hitPoint ) {

    Triple d = a.vectorTo( hitPoint );

    int firstHit = -1;
    double firstLambda = -1;

    for ( int k=0; k<editable.size(); k++ ) {
       double lambda = editable.get(k).whenHitByRay( a, d );
      if ( lambda >= 1 && (lambda < firstLambda || firstLambda==-1) ) {
         // found first hit or an earlier hit
         firstHit = k;
         firstLambda = lambda;
      }
    }

    if (firstHit >= 0) {
       // got a hit
       return firstHit;
    }
    else {
      return -1;
    }

  }

  // return index of editable assembly (if any)
  // that is hit by ray from eye to hitPoint
  // --- finds first in the list, not first geometrically
  private int findAssemblyHitByRay( Triple a, Triple hitPoint ) {

    Triple d = a.vectorTo( hitPoint );

    for( int k=0; k<editable.size(); k++ ) {
      if( editable.get(k).hitByRay( a, d ) )
        return k;
    }

    return -1;
  }

  private int findAssemblyTouching( ArrayList<Assembly> list, double x, double y, double z ) {
    
    int loc = -1;

    for( int k=0; k<list.size() && loc==-1;  k++ ) {
      Assembly a = list.get(k);
      if( a.touches( x, y, z ) ) {
        loc = k;
      }
    }

    return loc;
    
  }// findAssemblyTouching

  protected void update()
  {
    //  System.out.println( getStepNumber() + "================================" );

  }// update

  protected void display() {
     //    System.out.println( "******************* " + getStepNumber() +
     //  " # perm: " + perm.size() + " # editable: " + editable.size() );

     // turn off console info to user when debugging
     if ( !debug && showInfo ) {
        // clear console
        System.out.print("\033[H\033[2J");

        if ( attached ) {
           System.out.print("Cursor attached to ");
           if ( current == null ) {
              System.out.print("nothing, at ");
              cursor.consoleDisplay();    
           }
           else 
              current.consoleDisplay();
        }
        else {// not attached
           System.out.print("Cursor detached, at ");
           cursor.consoleDisplay();
        }

        if (flyingCameras)
           camera[curCam].consoleDisplay( "flying" );
        else
           camera[curCam].consoleDisplay( "shifting" );

        System.out.println("               edit amount: " + amount );

        System.out.println("------------------------------");

    }// not debugging

     showInfo = false;  // set to true if any input is processed

    // start with empty soups for editable assemblies
    if( editableSoups != null )
      editableSoups.cleanup();
    editableSoups = new Soups( Pic.size() );

    editableSoups.addAll( editable );
    editableSoups.sortByTexture();

    // System.out.println("editable soup prepared to draw" );

    if( cursorSoups != null )
      cursorSoups.cleanup();
    cursorSoups = new Soups( Pic.size() );
    cursorSoups.addTris( cursor.getTriangles() );
    cursorSoups.sortByTexture();

    if( cameraSoups != null )
      cameraSoups.cleanup();
    cameraSoups = new Soups( Pic.size() );
    for (int k=0; k<camera.length; k++) {
       if (k == curCam)
          cameraSoups.addTris( camera[k].getTriangles(true) );
       else
          cameraSoups.addTris( camera[k].getTriangles(false) );
    }
    cameraSoups.sortByTexture();

    // clear entire window to background color
    OpenGL.drawBackground();

    // draw the first person view on the left
    // -----------------------------------------------------

    camera[curCam].activate();
    permSoups.draw();
    // System.out.println("permSoups finished drawing");
    editableSoups.draw();
    // System.out.println("editableSoups finished drawing");
    cursorSoups.draw();
    // System.out.println("cursorSoups finished drawing");
    cameraSoups.draw();
    // System.out.println("cameraSoups finished drawing");

    // draw the map view on the right
    // -----------------------------------------------------

    mapCam.activate();

    permSoups.draw();
    // System.out.println("permSoups finished drawing");
    editableSoups.draw();
    // System.out.println("editableSoups finished drawing");
    cursorSoups.draw();
    // System.out.println("cursorSoups finished drawing");
    cameraSoups.draw();
    // System.out.println("cameraSoups finished drawing");

  }// display

}// Builder
