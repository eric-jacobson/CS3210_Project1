/* 
  treasure is like wall except
  touching it wins the game
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Treasure extends Block {

  // texture info for the 6 faces---shared over all Treasure blocks
  private static int[] texs = {19,19,19,19,20,19};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  private static double[] scales = {8,8,8,8,2,8};  // each kind of block has its own texture
                                               // scaling

   private ClipInfo foundIt;

  public Treasure( Scanner input ) {
    super( input );  // get location and size
    kind = "Treasure";
    textures = Treasure.texs;
    texScales = Treasure.scales;

    foundIt = new ClipInfo( "found it", "Sounds/foundIt.wav" );
  }

  public Treasure( double ctrX, double ctrY, double ctrZ, double sizeX, double sizeY, double sizeZ ) {
    super( "Treasure", ctrX, ctrY, ctrZ, sizeX, sizeY, sizeZ );
    textures = Treasure.texs;
    texScales = Treasure.scales;

    foundIt = new ClipInfo( "found it", "Sounds/foundIt.wav" );
  }

   protected void becomeGhost() {
      super.becomeGhost();
      foundIt.play(false);
      countdown = 50;
   }

}// Treasure
