/*
  mine is a kind of block
  that blows up whenever an explorer
  or a bullet touches it
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Mine extends Block {

  // texture info for the 6 faces---shared over all Mine blocks
  // (same pics as floor)
  private static int[] texs = {7,7,7,7,7,7};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  // but with different scaling so shows up somewhat
  private static double[] scales = {4,4,4,4,4,4};  // each kind of block has its own texture
                                               // scaling

   public static double typWidth = 4, typLength = 8, typHeight = 1;

  public Mine( Scanner input ) {
    super( input );  // get location and size
    kind = "Mine";
    textures = Mine.texs;
    texScales = Mine.scales;
  }

  public Mine( double ctrX, double ctrY, double ctrZ,
               double sizeX, double sizeY, double sizeZ ) {
    super( "Mine", ctrX, ctrY, ctrZ, sizeX, sizeY, sizeZ );
    textures = Mine.texs;
    texScales = Mine.scales;
  }

  // construct copy of other with center changed to (a,b,c)
  public Mine( Mine other, double a, double b, double c ) {
    super( "Mine", a, b, c, other.sx, other.sy, other.sz );
    textures = Mine.texs;
    texScales = Mine.scales;
  }

  protected void becomeGhost() {
     super.becomeGhost();
     countdown = 30;
  }

}// Mine
