/*
  an octtree node is one node in
  an octtree that
   
   permanently holds all fixed blocks

   on each time step can have each mobile
   block added to the tree, noticing all the
   while all pairs of blocks that share a
   node and hence might collide and hence
   need to have CCD run on them

*/

import java.util.ArrayList;

public class OctTreeNode {

   private static OctTreeNode head = null, tail = null;

   // this node's center point
   private Triple center;

   // the size of this node which is axis-aligned distance
   // from center to boundary faces
   private double size;

   // has 8 nodes that can point to children
   // subdivide cube into left, right, near, far, bottom, top
   // (lr for x, nf for y, bt for z)
   private OctTreeNode lfb, lnb, rfb, rnb,
                       lft, lnt, rft, rnt;

   // maintain unchanging (once built) list of
   // fixed blocks that touch the volume of this node
   private ArrayList<Block> fixed;

   // keep separate list of mobile blocks that
   // might touch the volume of this node as they
   // move
   private ArrayList<Block> mobile;
   
   // all nodes are arranged in a singly-linked list
   // for traversal to clear out all mobile block info
   private OctTreeNode next;

   // construct a node with given bounds
   public OctTreeNode( Triple c, double s ) {
      center = c;
      size = s;

      // all children are null automatically

      fixed = new ArrayList<Block>( 1 );  // builds list assuming will have just 1

      // leave mobile null
      
      // manage the linked list of all nodes:
      if (tail == null) {// add first node
         head = this;
         tail = this;
      }
      else {// add node on end
         tail.next = this;
      }

   }

   // given an AABB that is part of the given block
   // that is contained in this node, add the block
   // to this node, meaning recurse downward through
   // 
   public static void add( AABB aabb, Block block ) {
      
      AABB aabb = block.getAABB();


   }

}
