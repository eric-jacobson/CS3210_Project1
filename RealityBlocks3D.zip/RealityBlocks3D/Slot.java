public class Slot
{
  public Block block;  // block that mapped here
  public int i, j, k;  // the cell x, y, z values that mapped here

  public Slot next;  // pointer to the next used slot in the table

  public Node( Block blockIn, int iIn, int jIn, int kIn ) {  
    block = blockIn;  
    i = iIn;  j = jIn;  k = kIn;  
  }

}
