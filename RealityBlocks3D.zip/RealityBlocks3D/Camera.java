/*
   a camera maintains the 
   viewport, projection, and
   viewing info
   (using azimuth,altitude,+z is up
     scheme)
*/

import java.util.ArrayList;

import static org.lwjgl.glfw.GLFW.*;  // for key codes

public class Camera{
  
  private int id;  // so camera knows which one it is for console display
                   // and for color scheme

  private boolean perspView;  // perspective or orthogonal viewing

  private int px, py, pw, ph;  // viewport info
  private double left, right, bottom, top, near, far;  // projection info
  private Mat4 proj;  // corresponding matrix
  private int projLoc;  // uniform location

  // view info
  private double eyeX, eyeY, eyeZ, azimuth, altitude;
  private Mat4 view;  // corresponding matrix
  private int viewLoc;  // uniform location

  public Camera( boolean perspective, 
                 int idIn, int vx, int vy, int vw, int vh, 
                 double l, double r, double b, double t, double n, double f,
                 double ex, double ey, double ez,
                 double azi, double alt ){

    id = idIn;

    perspView = perspective;

    if (perspView) {

       px=vx; py=vy; pw=vw; ph=vh;

       left=l;  right=r; bottom=b; top=t; near=n; far=f;
       proj = Mat4.frustum( left, right, bottom, top, near, far );

       eyeX=ex; eyeY=ey; eyeZ=ez;
       azimuth = azi;  altitude = alt;

       updateView();
    }
    else {// parallel viewing

       px=vx; py=vy; pw=vw; ph=vh;

       left=l;  right=r; bottom=b; top=t; near=n; far=f;

       proj = Mat4.ortho( left, right, bottom, top, near, far );

       eyeX=ex; eyeY=ey; eyeZ=ez;
       azimuth = azi;  altitude = alt;

       updateView();
      
    }

       projLoc = OpenGL.getUniformLoc( "proj" );
       viewLoc = OpenGL.getUniformLoc( "view" );
  }

  public String getUserInfo() {
    return eyeX + " " + eyeY + " " + eyeZ + " " + azimuth + " " + altitude +
           "           Camera " + id;
  }

  // recompute view matrix because info has changed
  public void updateView(){

    if (perspView) {

       double c = Math.cos( Math.toRadians( azimuth ) );
       double s = Math.sin( Math.toRadians( azimuth ) );
       double c2 = Math.cos( Math.toRadians( altitude ) );
       double s2 = Math.sin( Math.toRadians( altitude ) );

       view = Mat4.lookAt( eyeX, eyeY, eyeZ, 
                           eyeX + c*c2, eyeY + s*c2, eyeZ + s2,
                           0, 0, 1 );
    }
    else {// parallel view
       // had just identity matrix for view, silly mistake
       view = Mat4.translate( -eyeX, -eyeY, -eyeZ );
    }

  }

  // return unit vector from eye point to look at point
  public Triple getDirection() {
    // same as in updateView:
    double c = Math.cos( Math.toRadians( azimuth ) );
    double s = Math.sin( Math.toRadians( azimuth ) );
    double c2 = Math.cos( Math.toRadians( altitude ) );
    double s2 = Math.sin( Math.toRadians( altitude ) );

    return new Triple( c*c2, s*c2, s2 );
  }

  // return location of this camera
  public Triple getLocation() {
    return new Triple( eyeX, eyeY, eyeZ );
  }

  // return x-y rotation of camera
  public double getAzimuth() {
    return azimuth;
  }

  // set up viewport and send matrices
  public void activate(){

    OpenGL.viewport( px, py, pw, ph );

    OpenGL.sendUniformMatrix4( projLoc, proj );
    OpenGL.sendUniformMatrix4( viewLoc, view );

  }

  // shift eye point by given vector
  public void shift( double dx, double dy, double dz ){
    eyeX += dx; eyeY += dy; eyeZ += dz;
    updateView();
  }

  // shift eye point to given location
  public void shiftTo( double dx, double dy, double dz ){
    eyeX = dx; eyeY = dy; eyeZ = dz;
System.out.println("new camera loc is " + eyeX + " " + eyeY + " " + eyeZ );
    updateView();
  }

  // change azimuth by given amount
  public void turn( double amount ){
    azimuth += amount;
    if( azimuth < 0 )
      azimuth += 360;
    if( azimuth > 360 )
      azimuth -= 360;
    updateView();
  }

  // change azimuth to given angle
  public void turnTo( double angle ){
    azimuth = angle;
    if( azimuth < 0 )
      azimuth += 360;
    if( azimuth > 360 )
      azimuth -= 360;
    updateView();
  }

  // change altitude by given amount
  public void tilt( double amount ){
    if( amount > 0 && altitude + amount <= 90-amount ) altitude += amount;
    if( amount < 0 && altitude + amount >= -90-amount ) altitude += amount;
    updateView();
  }

  // change altitude to given angle
  public void tiltTo( double angle ){
    if( -89 <= angle && angle <= 89 )
      altitude = angle;
    updateView();
  }

  // change azimuth to next multiple of Util.gridAngle
  // in ccw or cw direction
  // (needs azimuth in [0,360) to work correctly)
  public void turnToNext( boolean ccw ) {
     int angle = (int) Math.round(azimuth);  // tidy up---should be integral, anyway

     if (ccw) {// turn big amount left
        azimuth = ( (angle/Util.gridAngle + 1) * Util.gridAngle ) % 360;
     }
     else {// turn big amount right
        if (angle <= 0) {// take care of 0 case--- 0 == 360, in a sense
           angle += 360;
        }
        azimuth = ( ( (angle - 1) / Util.gridAngle) * Util.gridAngle ) % 360;
     }

     updateView();

  }// turnToNext

  public void consoleDisplay( String status ) {
    System.out.printf("Camera %d  %s at %.2f %.2f %.2f azi: %d alt: %d\n",  
            id, status, eyeX, eyeY, eyeZ, (int) azimuth, (int) altitude );
  }

  // produce (x,y,z) rotated through altitude and azimuth
  private Triple rotate(double c1, double s1, double c2, double s2,
                        double x, double y, double z) {
     return new Triple(c2*c1*x - s2*y - c2*s1*z,
                       s2*c1*x + c2*y - s2*s1*z,
                       s1*x + c1*z);
  }

  // return list of triangles forming picture
  // for this camera 
  public ArrayList<Triangle> getTriangles(boolean current) {

    int centerImage;
    if (current)
       centerImage = 16;  // current camera has whiteish center
    else
       centerImage = 17;  // non-current has blackish center

    // model camera
    final double S = 2; // 0.25;  // half side length of base square
    final double H = 16;    // height of pointy tip above base

    double alt = Math.toRadians(altitude);
    double azi = Math.toRadians(azimuth);

    double c1 = Math.cos(alt);
    double s1 = Math.sin(alt);
    double c2 = Math.cos(azi);
    double s2 = Math.sin(azi);

    Triple bn, bf, tn, tf, tip;  // the bottom near, ...top far verts

    // rotate the model verts about origin:
    bn = rotate(c1,s1,c2,s2, -H, -S, -S );
    bf = rotate(c1,s1,c2,s2, -H, S, -S );
    tn = rotate(c1,s1,c2,s2, -H, -S, S );
    tf = rotate(c1,s1,c2,s2, -H, S, S );
    tip = rotate(c1,s1,c2,s2, 0, 0, 0 );

    ArrayList<Triangle> list = new ArrayList<Triangle>();

    // create the vertices for three triangles on each of 4 faces:
    
    Triple a, b, c;  // spatial locations of the three vertices
    Vertex va, vb, vc;  // reuse as we go to hold each corner of a triangle

    // top face of camera body:  ---------------------------------
    buildFace( tf, tn, tip, 11, centerImage, list );

    // front face of camera body:  ---------------------------------
    buildFace( tn, bn, tip, 12, centerImage, list );

    // bottom face of camera body:  ---------------------------------
    buildFace( bn, bf, tip, 10, centerImage, list );

    // back face of camera body:  ---------------------------------
    buildFace( bf, tf, tip, 13, centerImage, list );

    // build two triangles for butt of camera:
    
    int screenColor = 18;

    a = bf;  b = bn;  c = tf;
    va = new Vertex( eyeX+a.x, eyeY+a.y, eyeZ+a.z, 0, 0 );
    vb = new Vertex( eyeX+b.x, eyeY+b.y, eyeZ+b.z, 1, 0 );
    vc = new Vertex( eyeX+c.x, eyeY+c.y, eyeZ+c.z, 0, 1 );
    list.add( new Triangle( va, vb, vc, screenColor ) );

    a = tf;  b = bn;  c = tn;
    va = new Vertex( eyeX+a.x, eyeY+a.y, eyeZ+a.z, 0, 1 );
    vb = new Vertex( eyeX+b.x, eyeY+b.y, eyeZ+b.z, 1, 0 );
    vc = new Vertex( eyeX+c.x, eyeY+c.y, eyeZ+c.z, 1, 1 );
    list.add( new Triangle( va, vb, vc, screenColor ) );

    return list;
  }

   // draw face of camera 
   // given endpoints of base of three triangles and tip, and colors
   private void buildFace( Triple first, Triple second, Triple tip,
                           int faceColor, int centerColor,
                           ArrayList<Triangle> list ) {
      Triple a, b, c;
      Vertex va, vb, vc;

      a = first;  b = first.ofTheWay(1/3.0, second);  c = tip;
      va = new Vertex( eyeX + a.x, eyeY + a.y, eyeZ + a.z, 0, 0 );
      vb = new Vertex( eyeX + b.x, eyeY + b.y, eyeZ + b.z, 0.5, 0 );
      vc = new Vertex( eyeX + c.x, eyeY + c.y, eyeZ + c.z, 1, 1 );
      list.add( new Triangle( va, vb, vc, faceColor ) );

      a = b;  b = first.ofTheWay(2/3.0,second);  
      va = new Vertex( eyeX + a.x, eyeY + a.y, eyeZ + a.z, 0, 0 );
      vb = new Vertex( eyeX + b.x, eyeY + b.y, eyeZ + b.z, 1, 0 );
      vc = new Vertex( eyeX + c.x, eyeY + c.y, eyeZ + c.z, 0.5, 1.0 );
      list.add( new Triangle( va, vb, vc, centerColor ) );

      a = b;  b = second;  
      va = new Vertex( eyeX + a.x, eyeY + a.y, eyeZ + a.z, 0.5, 0 );
      vb = new Vertex( eyeX + b.x, eyeY + b.y, eyeZ + b.z, 1, 0 );
      vc = new Vertex( eyeX + c.x, eyeY + c.y, eyeZ + c.z, 0.5, 1.0 );
      list.add( new Triangle( va, vb, vc, faceColor ) );

   }// buildFace


   public void moveOrFly(int code, int mods, double amount, double aziAmount, double altAmount,
                           boolean fly) {

      if ( !fly ) {// shift

         if( code == GLFW_KEY_KP_1 && mods == 0 )    
            shift( -amount, 0, 0 );
         else if( code == GLFW_KEY_KP_3  && mods == 0 )  
            shift( amount, 0, 0 );
         else if( code == GLFW_KEY_KP_4  && mods == 0 )  
             shift( 0, -amount, 0 );
         else if( code == GLFW_KEY_KP_6  && mods == 0 )  
             shift( 0, amount, 0 );
         else if( code == GLFW_KEY_KP_7  && mods == 0 )  
             shift( 0, 0, -amount );
         else if( code == GLFW_KEY_KP_9  && mods == 0 )  
             shift( 0, 0, amount );

      }// shift
      else {// flying

         if( code == GLFW_KEY_KP_1 && mods == 0 )    
            turn( aziAmount );
         else if( code == GLFW_KEY_KP_3  && mods == 0 )  
            turn( -aziAmount );

         else if ( code == GLFW_KEY_KP_4  && mods == 0 )
            turnToNext( true );
         else if ( code == GLFW_KEY_KP_6  && mods == 0 )
            turnToNext( false );
 
         else if( code == GLFW_KEY_KP_2  && mods == 0 ) {// move back amount
           Triple v = getDirection();
           eyeX -= amount * v.x;
           eyeY -= amount * v.y;
           eyeZ -= amount * v.z;
           updateView();
         }

         else if( code == GLFW_KEY_KP_5  && mods == 0 ) {// move forward amount
           Triple v = getDirection();
           eyeX += amount * v.x;
           eyeY += amount * v.y;
           eyeZ += amount * v.z;
           updateView();
         }

         else if( code == GLFW_KEY_KP_7 && mods == 0 )
             tilt( -altAmount );
         else if( code == GLFW_KEY_KP_9 && mods == 0 )
              tilt( altAmount );
         else if( code == GLFW_KEY_KP_8 && mods == 0 ) // tilt head level
              tiltTo( 0 );

      }// flying
    
   }// move

}// Camera
