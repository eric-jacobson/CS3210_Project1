/*  encapsulate
    cursor data
    and behavior
(is just a location in 3D plus
display)
*/

import java.util.Scanner;
import java.util.ArrayList;

public class Cursor {

  private static double s = 0.5;  // half-size of square faces
  private static double a = 7;  // altitude of octahedra

  private double x, y, z;  // center of cursor

  public Cursor( Scanner input ) {
    x = input.nextDouble();
    y = input.nextDouble();
    z = input.nextDouble();
    input.nextLine();

  }

  public String getLocString() {
    return x + " " + y + " " + z + "               cursor";
  }

  public void move( double dx, double dy, double dz ) {
    x += dx;
    y += dy;
    z += dz;
  }

  // maybe only used for debugging
  public void moveTo( double tx, double ty, double tz ) {
    x=tx;  y=ty;  z=tz;
  }

  public double getX() {  return x;  }
  public double getY() {  return y;  }
  public double getZ() {  return z;  }

  // move this cursor to have same center as 
  // current
  public void moveWith( Assembly current ) {
    x = current.getX();
    y = current.getY();
    z = current.getZ();

  }

  // return list of triangles forming picture
  // for the cursor 
  public ArrayList<Triangle>  getTriangles() {
    ArrayList<Triangle> list = new ArrayList<Triangle>();

    // vertex names use old-school, frustum labeling
    // where y is up and down---confusing because
    // in modeling we use z for up and down

    Vertex lbn1 = new Vertex( x-s, y-s, z-s, 0, 0 );   // near face
    Vertex rbn1 = new Vertex( x+s, y-s, z-s, 0, 0 );
    Vertex rtn1 = new Vertex( x+s, y+s, z-s, 0, 0 );
    Vertex ltn1 = new Vertex( x-s, y+s, z-s, 0, 0 );
    Vertex lbn2 = new Vertex( x-s, y-s, z-s, 1, 0 );   // near face
    Vertex rbn2 = new Vertex( x+s, y-s, z-s, 1, 0 );
    Vertex rtn2 = new Vertex( x+s, y+s, z-s, 1, 0 );
    Vertex ltn2 = new Vertex( x-s, y+s, z-s, 1, 0 );

    Vertex lbf1 = new Vertex( x-s, y-s, z+s, 0, 0 );   // far face
    Vertex rbf1 = new Vertex( x+s, y-s, z+s, 0, 0 );
    Vertex rtf1 = new Vertex( x+s, y+s, z+s, 0, 0 );
    Vertex ltf1 = new Vertex( x-s, y+s, z+s, 0, 0 );
    Vertex lbf2 = new Vertex( x-s, y-s, z+s, 1, 0 );   // far face
    Vertex rbf2 = new Vertex( x+s, y-s, z+s, 1, 0 );
    Vertex rtf2 = new Vertex( x+s, y+s, z+s, 1, 0 );
    Vertex ltf2 = new Vertex( x-s, y+s, z+s, 1, 0 );

    // 6 tip vertices
    Vertex right = new Vertex( x+s+a, y, z, 0.5, 1 );
    Vertex left = new Vertex( x-s-a, y, z, 0.5, 1 );
    Vertex back = new Vertex( x, y, z+s+a, 0.5, 1 );
    Vertex front = new Vertex( x, y, z-s-a, 0.5, 1 );
    Vertex top = new Vertex( x, y+s+a, z, 0.5, 1 );
    Vertex bottom = new Vertex( x, y-s-a, z, 0.5, 1 );

    // make 24 triangles
    
    list.add( new Triangle( rtn1, rbn2, right, 8 ) );
    list.add( new Triangle( rbn1, rbf2, right, 8 ) );
    list.add( new Triangle(  rbf1, rtf2, right, 8 ) );
    list.add( new Triangle( rtf1, rtn2, right, 8 ) );

    list.add( new Triangle( ltf1, rtf2, back, 11 ) );
    list.add( new Triangle( rtf1, rbf2, back, 11 ) );
    list.add( new Triangle( rbf1, lbf2, back, 11 ) );
    list.add( new Triangle( lbf1, ltf2, back, 11 ) );

    list.add( new Triangle( ltn1, ltf2, left, 9 ) );
    list.add( new Triangle( ltf1, lbf2, left, 9 ) );
    list.add( new Triangle( lbf1, lbn2, left, 9 ) );
    list.add( new Triangle( lbn1, ltn2, left, 9 ) );

    list.add( new Triangle( lbn1, rbn2, front, 10 ) );
    list.add( new Triangle( rbn1, rtn2, front, 10 ) );
    list.add( new Triangle( rtn1, ltn2, front, 10 ) );
    list.add( new Triangle( ltn1, lbn2, front, 10 ) );

    list.add( new Triangle( ltn1, rtn2, top, 13 ) );
    list.add( new Triangle( rtn1, rtf2, top, 13 ) );
    list.add( new Triangle( rtf1, ltf2, top, 13 ) );
    list.add( new Triangle( ltf1, ltn2, top, 13 ) );

    list.add( new Triangle( rbn1, lbn2, bottom, 12 ) );
    list.add( new Triangle( rbf1, rbn2, bottom, 12 ) );
    list.add( new Triangle( lbf1, rbf2, bottom, 12 ) );
    list.add( new Triangle( lbn1, lbf2, bottom, 12 ) );

    return list;
  }

  public void consoleDisplay() {
    System.out.printf("%.2f %.2f %.2f\n", x, y, z );
  }

}
