import java.util.*;

/*  store info on AABB/Block pairs using a 
    spatial grid
*/

public class CellTable
{
  // side length of a grid cubelet
  public static double gridSize = 4;

  // number of cells in the hash array
  private static int numCells = 17;  // stub 17, should be largeish and prime, like 10007

  // the hash array
  private Cell[] cells;

  private ArrayList<Integer> usedForMobiles;

  public CellTable() {
     cells = new Cell[numCells];
     // initialize all cells because most will be used anyway
     for (int k=0; k<numCells; k++) {
        cells[k] = new Cell();
     }
     usedForMobiles = new ArrayList<Integer>();     
  }

  private static int hashMap( int i, int j, int k ) {

     // System.out.println("hash map on " + i + " " + j + " " + k);
// stub:

    int result = (int) ( Math.abs(i+j+k) % numCells);
     // System.out.println("got result " + result );
     // System.out.println("hash map result is " + result );
    return result;

/*
    // randomish prime numbers
    int result = (int) ( (((((557731L*i) % numCells) + 221827L*k) % numCells) + 
                198193L*j + 350249L) % numCells );
    if( result < 0 )
      result += numCells;
    return result;
*/

  }

  // note in the table the cells that the 
  // given fixed block touches
  // known as "registering" the block
  public void registerFixed( Block block )
  {
    AABB aabb = block.getAABB();

    int left = getGridCoord( aabb.left );   // x axis
    int right = getGridCoord( aabb.right );
    int near = getGridCoord( aabb.near );   // y axis
    int far = getGridCoord( aabb.far );
    int bottom = getGridCoord( aabb.bottom ); // z axis
    int top = getGridCoord( aabb.top );

    for( int i=left; i<=right; i++ )
      for( int j=near; j<=far; j++ )
        for( int k=bottom; k<=top; k++ ) {
           noteCellFixed( i, j, k, block );
        }
  }

  // note in the table the cells that the
  // given aabb (either stationary or swept for
  // given mobile block) touches
  // Known as "registering" the block
  public void registerMobile( AABB aabb, Block block )
  {
    int left = getGridCoord( aabb.left );   // x axis
    int right = getGridCoord( aabb.right );
    int near = getGridCoord( aabb.near );   // y axis
    int far = getGridCoord( aabb.far );
    int bottom = getGridCoord( aabb.bottom ); // z axis
    int top = getGridCoord( aabb.top );

    for( int i=left; i<=right; i++ )
      for( int j=near; j<=far; j++ )
        for( int k=bottom; k<=top; k++ ) {
           noteCellMobile( i, j, k, block );
        }
  }

  // partition space into cubical cells of sidelength cellSize in all
  // three axes, with lower faces included, upper excluded
  private int getGridCoord( double a )
  {
     // System.out.println("get grid coord for " + a );
    return (int) Math.floor(a/gridSize+0.5);
  }

  // hash map fixed block, (i,j,k) to a spot in cells
  private void noteCellFixed( int i, int j, int k, Block block )
  {
    int index = hashMap( i, j, k );

    HashInfo hi = new HashInfo( i, j, k, block );
    cells[ index ].addFixed( hi );
  }

  // hash map mobile block, (i,j,k) to a spot in cells
  // (carefully monitors cells used for efficient unregistering)
  private void noteCellMobile( int i, int j, int k, Block block )
  {
    int index = hashMap( i, j, k );

    HashInfo hi = new HashInfo( i, j, k, block );

    cells[index].addMobile( hi, index, usedForMobiles );
  }

   // clear all info for mobiles
   public void clearMobiles() {
      for (int k=0; k<usedForMobiles.size(); k++) {
         cells[ usedForMobiles.get(k) ].clear();
      }
     
      usedForMobiles.clear();
   }

  // return a list of
  // all blocks (with no duplicates)
  // in the hash table
  // that share a cell with the given aabb (derived somehow from the
  // given block) but are not it
  // 
  // This is the broad phase method for checking whether a given
  // block/aabb is perhaps touching any other blocks so
  // precise overlap or support checks can be done
  //
  // Used when mobiles are registered, but does not change anything in the table

  public ArrayList<Block> mightOverlap( AABB aabb, Block block ) {

    // System.out.println("do mightOverlap with " + block.getId() );

    // build empty list to add to and return:
    ArrayList<Block> list = new ArrayList<Block>();

    int left = getGridCoord( aabb.left );
    int right = getGridCoord( aabb.right );
    int near = getGridCoord( aabb.near );
    int far = getGridCoord( aabb.far );
    int bottom = getGridCoord( aabb.bottom );
    int top = getGridCoord( aabb.top );

    int index;

    for( int i=left; i<=right; i++ )
      for( int j=near; j<=far; j++ )
        for( int k=bottom; k<=top; k++ ) {
          // for each cell this block touches, scan the
          // linked list stored there and note any overlaps
 
          index = hashMap( i, j, k );

          cells[ index ].noteTouches( new HashInfo(i,j,k,block), list );

        }// for each cell touched by aabb

     // System.out.print("might touch: ");
     // for (int k=0; k<list.size(); k++) {
       //  System.out.print( list.get(k).getId() + " " );
     // }
     // System.out.println();

     return list;

  }// mightHit

   // check all grid cubes that block's swept volume (for given time) touches, and
   // add to pairs all pairs of block and another block that touches
   // the same grid cube
   //  Mobile blocks are registered one by one, and kept track of for
   // later clearing
   public void registerMobiles( Block block, ArrayList<BlockPair> pairs, double time ) {
   
      int start = pairs.size();  // index to begin looking for duplicates

      AABB aabb = block.getSweptAABB( time );

      int left = getGridCoord( aabb.left );
      int right = getGridCoord( aabb.right );
      int near = getGridCoord( aabb.near );
      int far = getGridCoord( aabb.far );
      int bottom = getGridCoord( aabb.bottom );
      int top = getGridCoord( aabb.top );

      int index;

      // System.out.println("registerMobiles for block " + block.getId() );

      for ( int i=left; i<=right; i++ )
         for ( int j=near; j<=far; j++ )
            for ( int k=bottom; k<=top; k++ ) {

               index = hashMap( i, j, k );

               // add all pairs with block and any block that
               // touches grid cube (i,j,k)

               // System.out.println("noteTouches with " + i + " " + j + " " + k + 
               //                     " and index " + index );

               cells[ index ].noteTouches( new HashInfo(i,j,k,block), 
                                           pairs, start, 
                                           index, usedForMobiles );

        }// for each cell touched by aabb

      
   }

   // display full info about this table
   public void show() {
      
      // display cells
      for (int k=0; k<cells.length; k++) {
         if (cells[k] != null) {
            System.out.print( k + ":  " + cells[k] );
         }         
      }

      // display usedForMobiles
      System.out.print("      cells used for mobiles: ");
      for (int k=0; k<usedForMobiles.size(); k++) {
         System.out.print( usedForMobiles.get(k) + " " );
      }
      System.out.println();
   }

}// CellTable
