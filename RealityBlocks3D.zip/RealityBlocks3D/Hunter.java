/*
  hunter is a kind of block
  that exhibits primitive AI,
  is hostile to explorers

*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Hunter extends Block {

  // physical constants for hunter
  private static double SPEED = 1.0/12; 
                                        // which at 30 fps is 5 feet per second
  private static double SPEEDLIMIT = 1*SPEED; 

  // texture info for the 6 faces---shared over all Hunter blocks
  private static int[] texs = {24,25};  // texture number available

  private static double[] scales = {8,4,4,4,4,4};  // each kind of block has its own texture
                                               // scaling

  // Hunter computes its vel from these
  // more manageable quantities:
  private double bodyAngle;  // body angle in x-y plane and speed give x-y plane velocity component
  private double speed;  
  private double upward;  // the z component of velocity, changed by hopping and gravity

  private double headAngle;  // how head is tilted

  private Mat4 rotMat;  // current rotation of head, updated in updateCamera

  // Hunter sizes of things
  public final static double bodyWidth = 1, bodyHeight = 2, headSize = 0.5;

  // sound effects
  private ClipInfo blowUp;

  private final static double nearby = 30;  // distance within which hunter notices explorer

  public Hunter( double ctrX, double ctrY, double ctrZ, double azi ) {
    super( "Hunter", ctrX, ctrY, ctrZ, bodyWidth, bodyWidth, bodyHeight );
    bodyAngle = azi;   // start off with body aimed along given direction
    textures = Hunter.texs;
    texScales = Hunter.scales;

    updateVelocity();

    blowUp = new ClipInfo( "blow up", "Sounds/blowUp.wav" );

    state = "start";
  }

  // set vel from user-friendly data
  public void updateVelocity() {
    Triple horizVel = new Triple( Math.cos( Math.toRadians( bodyAngle ) ), 
                                  Math.sin( Math.toRadians( bodyAngle ) ), 0 );
    vel = horizVel.scalarProduct( speed ).add( new Triple(0,0,upward) );

    // update rotMat just like Explorer but head is never tilted
    final double headAngle = 0;
    rotMat = Mat4.rotate( bodyAngle, 0, 0, 1 ).mult( Mat4.rotate( headAngle, 0, -1, 0 ) );
 
  }

  // perform physics changes ========================================

  // turn body by amount
  public void turnBy( double amount ) {
    bodyAngle += amount;
    if( bodyAngle > 360 )  bodyAngle -= 360;
    if( bodyAngle < 0 ) bodyAngle += 360;
    updateVelocity();
  }

  // turn body to amount
  public void turnTo( double amount ) {
    bodyAngle = amount;
    if( bodyAngle > 360 )  bodyAngle -= 360;
    if( bodyAngle < 0 ) bodyAngle += 360;
    updateVelocity();
  }

  // change bodyAngle to next multiple of Util.gridAngle
  // in ccw or cw direction
  // (needs bodyAngle in [0,360) to work correctly)
  public void turnToNext( boolean ccw ) {
     System.out.print("body angle changing from " + bodyAngle );
     int angle = (int) Math.round(bodyAngle);  // tidy up---should be integral, anyway

     if (ccw) {// turn big amount left
        bodyAngle = ( (angle/Util.gridAngle + 1) * Util.gridAngle ) % 360;
     }
     else {// turn big amount right
        if (angle <= 0) {// take care of 0 case--- 0 == 360, in a sense
           angle += 360;
        }
        bodyAngle = ( ( (angle - 1) / Util.gridAngle) * Util.gridAngle ) % 360;
     }

     updateVelocity();

  }// turnToNext

  public void changeSpeedBy( double amount ) {
    if ( (speed + amount <= SPEEDLIMIT) &&
         (speed + amount >= -SPEEDLIMIT)
       ) {
       speed += amount;
       updateVelocity();
    }
  }

  public void changeSpeedTo( double amount ) {
    speed = amount;
    updateVelocity();
  }

  public void changeUpwardTo( double amount ) {
    upward = amount;
    updateVelocity();
    // System.out.println("vel is now " + vel );
  }

  // set velocity to 0, using manageable parameters
  public void stop() {
    speed = 0;
    upward = 0;
    updateVelocity();
  }

  public void verticalImpulse( double hop ) {
    upward += hop;   
    updateVelocity();
  }

  // update position of hunter over given time
  public void update( double time ) {
    super.update( time );
  }

  // perform requests for physics changes ==============================

  // fulfill all requests 
  // (subject to timing and attributes that may cause
  //  request to be put off or rejected)
  public void fulfillRequests() {

    super.fulfillRequests();  // do universal requests such as gravity

    // process remaining non-universal requests specially

    for( int k=0; k<requests.size(); k++ ) {
      Request req = requests.get(k);
      System.out.println("processing request " + req.kind );
      boolean remove = true;

      if( req.kind.equals( "turn" ) ) {
        if( supported )
          turnBy( req.amount );
      }
      else if( req.kind.equals( "turnTo" ) ) {
        if ( supported )
           turnTo( req.amount );
      }
      else if( req.kind.equals( "forward" ) ) {
         if( supported ) {// if supported increment speed to a limit
           changeSpeedBy( SPEED );
         }
      }
      else if( req.kind.equals( "backward" ) ) {
         if( supported ) {// if supported decrement speed to a limit
           changeSpeedBy( -SPEED );
         }
      }

      // request is now removed (unless still pending)
      if( remove ) {
        requests.remove( k );
        k--;
      }

    }// process request k

  }// fulfillRequests

  // override usual Block draw method to draw
  // special triangles for a hunter
  public void draw( ArrayList<Triangle> list ) {
     if ( ! isGhost ) {// draw with special stuff

        Vertex v1, v2, v3;  // convenience
    
        // 4 body triangles forming a pyramid:
    
        // front face (index 0) --------------------
    
        v1 = new Vertex( cx-sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy-sy, cz-sz, 2*sx/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                          2*sx/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // right face (index 1) --------------------
    
        v1 = new Vertex( cx+sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy+sy, cz-sz, 2*sy/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                           2*sy/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // back face (index 2) --------------------
    
        v1 = new Vertex( cx+sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy+sy, cz-sz, 2*sx/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                           2*sx/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // left face (index 3) --------------------
    
        v1 = new Vertex( cx-sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy-sy, cz-sz, 2*sy/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                           2*sy/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // draw the rotated head cube:
    
            // produce the 8 rotated and translated cube corner points (purely geometrical)
            Triple center = new Triple( cx, cy, cz + sz - headSize );
    
            // labeled by left/right, near/far, bottom/top
            Triple lnb = center.add( rotMat.mult( -headSize, -headSize, -headSize ) );
            Triple rnb = center.add( rotMat.mult( headSize, -headSize, -headSize ) );
            Triple lfb = center.add( rotMat.mult( -headSize, headSize, -headSize ) );
            Triple rfb = center.add( rotMat.mult( headSize, headSize, -headSize ) );
            Triple lnt = center.add( rotMat.mult( -headSize, -headSize, headSize ) );
            Triple rnt = center.add( rotMat.mult( headSize, -headSize, headSize ) );
            Triple lft = center.add( rotMat.mult( -headSize, headSize, headSize ) );
            Triple rft = center.add( rotMat.mult( headSize, headSize, headSize ) );
    
            // form all the triangles
            // (like default Block except use these 8 points instead of axis-aligned points)
    
            // front face (index 0) --------------------
        
            v1 = new Vertex( lnb, 
                                 0, 0 );
            v2 = new Vertex( rnb, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( rnt,
                              2*sx/texScales[0], 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lnb,
                                 0, 0 );
            v2 = new Vertex( rnt,
                                 2*sx/texScales[0], 2*sz/texScales[0] );
            v3 = new Vertex( lnt,
                                 0, 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // right face (index 1) --------------------
        
            v1 = new Vertex( rnb, 0, 0 );
            v2 = new Vertex( rfb, 1, 0 );
            v3 = new Vertex( rft, 1, 1 );
            list.add( new Triangle( v1, v2, v3, textures[1] ) );
        
            v1 = new Vertex( rnb, 0, 0 );
            v2 = new Vertex( rft, 1, 1 );
            v3 = new Vertex( rnt, 0, 1 ); 
            list.add( new Triangle( v1, v2, v3, textures[1] ) );
        
            // back face (index 2) --------------------
        
            v1 = new Vertex( rfb, 
                                 0, 0 );
            v2 = new Vertex( lfb, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( lft,
                                 2*sx/texScales[0], 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( rfb, 
                                 0, 0 );
            v2 = new Vertex( lft,
                                 2*sx/texScales[0], 2*sz/texScales[0] );
            v3 = new Vertex( rft,
                                 0, 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // left face (index 3) --------------------
        
            v1 = new Vertex( lfb, 
                                 0, 0 );
            v2 = new Vertex( lnb, 
                                 2*sy/texScales[0], 0 );
            v3 = new Vertex( lnt,
                                 2*sy/texScales[0], 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lfb,
                                 0, 0 );
            v2 = new Vertex( lnt,
                                 2*sy/texScales[0], 2*sz/texScales[0] );
            v3 = new Vertex( lft,  
                                 0, 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // top face (index 4) --------------------
        
            v1 = new Vertex( lnt, 
                                 0, 0 );
            v2 = new Vertex( rnt, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( rft, 
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lnt, 
                                 0, 0 );
            v2 = new Vertex( rft,
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            v3 = new Vertex( lft, 
                                 0, 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // bottom face (index 5) --------------------
        
            v1 = new Vertex( lfb,
                                 0, 0 );
            v2 = new Vertex( rfb, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( rnb,
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lfb, 
                                 0, 0 );
            v2 = new Vertex( rnb, 
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            v3 = new Vertex( lnb, 
                                 0, 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );

         }// draw specially
         else {
            super.draw( list );  // draw with random triangles
         }

  }// draw

  // if hunter goes through Gate, keeps trying forever
  // to arrive (hoping the block in the way will move)
  public boolean retriesArrival() {
    return true;
  }

  protected void becomeGhost() {
     super.becomeGhost();
     blowUp.play(false);
     countdown = 30;
  }

   private String state;

   // use when both explorers are alive
   public void behave( Explorer player1, Explorer player2 ) {

     if ( state.equals("start") ) {

        // determine angle to turn to 
        double angle;

        // see if an explorer is close and if so turn toward closer one

        double[] result1 = Block.lookToward( this, player1 );
        double[] result2 = Block.lookToward( this, player2 );

        // figure angle to closer of the two on same level
        //   and best distance

        double distance;

        if ( result1[0] == 1 ) {// player1 on same level
           if ( result2[0] == 1 ) {// both players on same level
              if ( result1[2] <= result2[2] ) {// player 1 closer
                 angle = result1[1];
                 distance = result1[2];
              }
              else {// player 2 closer
                 angle = result2[1];
                 distance = result2[2];
              }
           }
           else {// only player 1 on same level
              angle = result1[1];
              distance = result1[2];
           }
        }
        else {// player1 not on same level
           if ( result2[0] == 1 ) {// only player2 on same level
              angle = result2[1];
              distance = result2[2];
           }
           else {// neither player on same level
              angle = bodyAngle;
              distance = -1;
           }

        }

        if ( distance >= 0 && distance <= nearby ) {// turn and move toward explorer
           System.out.println("turn to angle " + angle + " and go" );
           addRequest( new Request( "turnTo",  angle ) );
           addRequest( new Request( "forward" ) );
        }

     }// start state

  }// behave (two players)

   // use when both explorers are alive
   public void behave( Explorer player ) {

     if ( state.equals("start") ) {

        // determine angle to turn to
        double angle;

        // see if an explorer is close and if so turn toward closer one

        double[] result = Block.lookToward( this, player );
        double distance;

        if ( result[0] == 1 ) {// player on same level
           angle = result[1];
           distance = result[2];
        }
        else {// player not on same level
           angle = bodyAngle;
           distance = -1;
        }

        if ( distance >= 0 && distance <= nearby ) {// turn and move toward explorer
           System.out.println("turn to angle " + angle + " and go" );
           addRequest( new Request( "turnTo",  angle ) );
           addRequest( new Request( "forward" ) );
        }

     }// start state

  }// behave (one player)

}// Hunter
