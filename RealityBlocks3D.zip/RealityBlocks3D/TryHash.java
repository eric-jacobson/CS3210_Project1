import java.util.Scanner;

public class TryHash {

  public static void main( String[] args ) {
    Scanner keys = new Scanner(System.in);
    do {
      System.out.println("enter a long: ");
      long x = keys.nextLong();
      System.out.println("hashes to " + (((int) Long.hashCode( x )) ) );
    } while(true);
  }

} 
