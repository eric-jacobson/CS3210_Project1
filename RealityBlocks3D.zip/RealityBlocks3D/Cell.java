/* a cell is a component
of the hash table

   stores list of fixed HashInfo objects
   that have been noted

   and temporary list for mobile
   HashInfo objects
*/

import java.util.ArrayList;

public class Cell {

   private ArrayList<HashInfo> fixed;
   private ArrayList<HashInfo> mobile;

   public Cell() {
      fixed = new ArrayList<HashInfo>(1);
   }

   // add given hashinfo to fixed list in
   // this cell
   public void addFixed( HashInfo hi ) {
      fixed.add( hi );
   }

   // add given hashinfo to mobile list in
   // this cell, and if is first, add to used
   // (index must be the hash function for (i,j,k)
   //  in hi)
   public void addMobile( HashInfo hi, int index, ArrayList<Integer> used ) {

      if (mobile == null) {
         mobile = new ArrayList<HashInfo>(1);
         used.add( index );         
      }
      else if (mobile.size()==0) {
         used.add( index );
      }

      mobile.add( hi );

   }

   // empty the mobile list
   // for this cell
   // (shouldn't get called unless mobile is non-null)
   public void clear() {
      mobile.clear();
   }

   // add to list all blocks that
   // touch the grid cube for target
   // but are not the same block,
   // and without duplicates
   public void noteTouches( HashInfo target, ArrayList<Block> list ) {

      // System.out.println("noteTouches for this cell: " + this + " against hashinfo " +
      //                     target );

      // check the fixed ones
      for (int k=0; k<fixed.size(); k++) {
         HashInfo hi = fixed.get(k);
          // System.out.print("trying " + hi );
          if ( target.matchesLocation( hi ) && target.block != hi.block &&
               ! list.contains( hi.block ) ) {// same cube, not self, not already in list
             // System.out.println("matches so add to list");
             list.add( hi.block );
          }
          else {
             // System.out.println("no match");
          }
      }

      // check the mobile ones, if any
      if ( mobile != null ) {
         for (int k=0; k<mobile.size(); k++) {
            HashInfo hi = mobile.get(k);
            // System.out.print("trying " + hi );
            if ( target.matchesLocation( hi ) && target.block != hi.block &&
                ! list.contains( hi.block ) ) {
               // System.out.println("matches so add to list");
               list.add( hi.block );
            }
            else {
               // System.out.println("no match");
            }
         }
      }

   }// noteTouches

   // add to list all pairs with target block
   // and another block both touching the
   // target cube,
   // and also register the target block as
   // touching this cell
   // But avoid duplicates efficiently by
   // knowing that start is the first index
   // that needs to be checked
   //
   // and if this is the first mobile being registered,
   // add index to usedForMobiles for later clearing
   public void noteTouches( HashInfo target, ArrayList<BlockPair> list, int start,
                            int index, ArrayList<Integer> usedForMobiles ) {

      // check the fixed ones
      for (int k=0; k<fixed.size(); k++) {
         HashInfo hi = fixed.get(k);
                   // (target block is mobile so can't match a fixed block)
         if ( target.matchesLocation( hi ) ) {
            // <target.block,hi.block> is a pair if not already in list
            Block a = target.block, b = hi.block;
            int j = -1;
            for (int m=start; m<list.size() && j<0; m++) {
               BlockPair checkee = list.get(m);
               if (checkee.equals(a,b)) {
                  j = m;
               } 
            }
            if (j < 0) {// not already in
               list.add( new BlockPair(a,b) );
            }
         }
      }// check fixed ones

      // check the mobile ones

      if ( mobile != null ) {
         for (int k=0; k<mobile.size(); k++) {
            HashInfo hi = mobile.get(k);
            if ( target.matchesLocation( hi ) && target.block != hi.block ) { 
               // <target.block,hi.block> is a pair if not already in list
               Block a = target.block, b = hi.block;
               int j = -1;
               for (int m=start; m<list.size() && j<0; m++) {
                  BlockPair checkee = list.get(m);
                  if (checkee.equals(a,b)) {
                     j = m;
                  }
               }
               if (j < 0) {// not already in
                  list.add( new BlockPair(a,b) );
               }
            }
         }// check mobile ones
      }// mobile exists at all

      // now add target to mobile unless already there
      // taking care to create mobile if not existing yet,
      // and adding index to usedForMobiles in that case

      if ( mobile == null ) {
         // mobile not built yet so for sure add stuff
         mobile = new ArrayList<HashInfo>(1);
         mobile.add( target );
         usedForMobiles.add( index );
      }
      else if ( mobile.size() == 0 ) {
         // mobile empty so add stuff
         mobile.add( target );
         usedForMobiles.add( index );
      }
      else {// mobile already has stuff
            // so don't add index to usedForMobiles
            // add target if not already in

         int j = -1;
         for (int m=0; m<mobile.size(); m++) {
            if ( target.equals(mobile.get(m)) ) {
               j = m;
            }
         }
         if (j < 0 ) {// not already in so add it
            mobile.add( target );
         }
      }

   }// noteTouches

   public String toString() {
      String r = "fixed: ";
      for (int k=0; k<fixed.size(); k++) {
         r += " " + fixed.get(k);
      }
       
      r += "\nmobile: ";
      if (mobile == null) {
         r += "-\n";
      }
      else {
         r += "[";
         for (int k=0; k<mobile.size(); k++) {
            r += " " + mobile.get(k);
         }
         r += "]\n";
      }

      return r;
   }// toString

}
