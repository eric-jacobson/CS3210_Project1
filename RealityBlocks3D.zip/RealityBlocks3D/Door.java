/*
  a door is a piece of
  door-like material
  that starts out at the
  start of the game being in
  the world, after t1 leaves for
  a time t2, then comes back in
  for t3, leaves for t4, then
  back in and repeats forever

  is a weird kind of block because
  it is created by a DoorFrame
  assembly, is only way can make one,
  and in Builder, is left empty
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Door extends Block {

  // texture info for the 6 faces---shared over all Door blocks
  private static int[] texs = {15,15,15,15,15,15,15,15};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  private static double[] scales = {3,1,3,1,3,1};  // each kind of block has its own texture
                                               // scaling

  private double pauseClosed, pauseOpen, stayClosed, stayOpen;

  public Door( double ctrX, double ctrY, double ctrZ, double sizeX, double sizeY, double sizeZ,
               double t1, double t2, double t3, double t4 ) {
    super( "Door", ctrX, ctrY, ctrZ, sizeX, sizeY, sizeZ );
    textures = Door.texs;
    texScales = Door.scales;
    pauseClosed = t1;
    pauseOpen = t2;
    stayClosed = t3;
    stayOpen = t4;
  }

}// Door
