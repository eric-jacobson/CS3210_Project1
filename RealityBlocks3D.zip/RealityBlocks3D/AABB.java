/*
  utility class to abstract stuff
  that only uses an Axis Aligned
  Bounding Box

  Is a simple utility class, so
  for convenience make IV's public
*/

public class AABB {

  // bounds along    x            y             z
  public double left, right, near, far, bottom, top;

  public AABB( double l, double r, double n, double f, double b, double t ) {
    left=l;  right=r;  
    near=n;  far=f;
    bottom=b;  top=t;
  }

  // use Liang-Barsky clipping algorithm to determine
  // entry and exit times for ray a+lambda d
  // (using -1 to signal never found---lambda=0 is 
  //  smallest that gives a point on the ray (as opposed
  //  to the line)
  public double[] whenHitByRay( Triple a, Triple d ) {
    double[] lambdas = new double[2];
    lambdas[0] = -1;  lambdas[1] = -1;

    // regularize various quantities and set up to use arrays
    // (all just for coding efficiency)
    double[] p = new double[7];  // waste p[0] to match notes
    double[] q = new double[7]; 

    p[1] = -d.x;  p[2] = d.x;
    p[3] = -d.y;  p[4] = d.y;
    p[5] = -d.z;  p[6] = d.z;

    q[1] = a.x - left;   q[2] = right - a.x;
    q[3] = a.y - near;   q[4] = far - a.y;
    q[5] = a.z - bottom;  q[6] = top - a.z;

    // detect miss or update lambdas for each equation
    for( int k=1; k<=6; k++ ) {
      if( p[k] == 0 ) {// ray parallel to face k
        if( q[k] < 0 ) {// ray outside face k
                        // so signal total miss
          trace("face " + k + ": ray parallel to face and outside");
          lambdas[0]=-1;  lambdas[1]=-1;
          return lambdas;
        }
        else {// ray inside face k,
          // but parallel so no updates, do nothing
          trace("face " + k + ": ray parallel to face and inside, do nothing");
        }
      }
      else {// p[k] != 0

        if( q[k] < 0 ) {// start point a is outside face k

          if( p[k] > 0 ) {// headed outward
                          // so total miss detected
            lambdas[0]=-1;  lambdas[1]=-1;
            trace("face " + k + ": outside headed out so miss");
            return lambdas;
          }// headed outward
          else {// headed inward
            // maybe update last entry time
            double lambda = q[k] / p[k];
            trace("face " + k + ": out headed in, computed lambda= " + lambda + ", update entry");
            lambdas[0] = Math.max( lambdas[0], lambda );
            trace("       : lambdas now " + lambdas[0] + " " + lambdas[1] );

            // early check for miss due to entry after exit
            if( lambdas[1] != -1 && lambdas[1] < lambdas[0] ) {// miss
              trace("              : exit < entry so miss");
              lambdas[0]=-1;  lambdas[1]=-1;
              return lambdas;
            }// miss

          }// headed inward

        }// outside face k

        else {// a is inside face k

          if( p[k] < 0 ) {// headed inward
            trace("face " + k + ": inside headed in, so do nothing");
            // do nothing---no miss detected
            // nor update face crossing
          }// headed inward

          else {// headed outward
            double lambda = q[k]/p[k];
            trace("face " + k + ": inside headed out, computed lambda= " + lambda );
            if( lambdas[1] == -1 )
              lambdas[1] = lambda;
            else
              lambdas[1] = Math.min( lambdas[1], lambda );

            trace("       : lambdas now " + lambdas[0] + " " + lambdas[1] );

            // early check for miss due to entry after exit
            if( lambdas[0] != -1 && lambdas[1] < lambdas[0] ) {// miss
              trace("              : exit<entry so miss");
              lambdas[0]=-1;  lambdas[1]=-1;
              return lambdas;
            }// miss

          }// headed outward

        }// inside face k
       
      }// p[k] != 0
    }

    // in cases where haven't already left
    return lambdas;

  }// whenHitByRay

  // produce a new AABB that is
  // expanded in the z direction
  // by collision tolerance
  public AABB zFluff() {
     final double fluff = Util.collTol;
     return new AABB( left, right, near, far, bottom - fluff, top + fluff );
  }

  private void trace( String s ) {
    // System.out.println( s );
  }

  // unit test ray-AABB intersection
  public static void main(String[] args) {
    AABB box;
    double[] lambdas;
    Triple a, d;

/*  tests with d: (1,1,0), (1,1,1), (1,1,-1), (1,1.5,1)

    box = new AABB( 10, 20, 20, 40, 10, 30 );
    a = new Triple(5,10,8);  d=new Triple(1,1.5,1);
    lambdas = box.whenHitByRay( a, d );
    System.out.println("entry time is " + lambdas[0] + " and exit time is " + lambdas[1] );
    if( lambdas[0] != -1 )
      System.out.println("entry point is " + Triple.linearComb( 1.0, a, lambdas[0], d ) );
    if( lambdas[1] != -1 )
      System.out.println("exit point is " + Triple.linearComb( 1.0, a, lambdas[1], d ) );
*/

/*  tests with d:  (1,1,1)  (1,2,1)

    box = new AABB( 10, 20, 20, 40, 10, 30 );
    a = new Triple(12,10,8);  d=new Triple(1,2,1);
    lambdas = box.whenHitByRay( a, d );
    System.out.println("entry time is " + lambdas[0] + " and exit time is " + lambdas[1] );
    if( lambdas[0] != -1 )
      System.out.println("entry point is " + Triple.linearComb( 1.0, a, lambdas[0], d ) );
    if( lambdas[1] != -1 )
      System.out.println("exit point is " + Triple.linearComb( 1.0, a, lambdas[1], d ) );
*/

/*  tests with d: (-1,-1,-1)
*/

    box = new AABB( 10, 20, 20, 40, 10, 30 );
    a = new Triple(30,45,35);  d=new Triple(-1,-1,-1);
    lambdas = box.whenHitByRay( a, d );
    System.out.println("entry time is " + lambdas[0] + " and exit time is " + lambdas[1] );
    if( lambdas[0] != -1 )
      System.out.println("entry point is " + Triple.linearComb( 1.0, a, lambdas[0], d ) );
    if( lambdas[1] != -1 )
      System.out.println("exit point is " + Triple.linearComb( 1.0, a, lambdas[1], d ) );

  }// main

}

