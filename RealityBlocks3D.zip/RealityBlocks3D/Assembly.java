/*  an assembly is
  an assembly of blocks,
  suitable for interactive
  editing

Assembly is the base class,
each extension has its own
instance variables in addition
to blocks
*/

import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;

public class Assembly {

  private static int currentId;
  public static void setCurrentId( int ident ) {  currentId = ident; }
  public static int getCurrentId() {  return currentId;  }

  protected int id;
  protected ArrayList<Block> blocks;
  protected String kind;

  public Assembly() {
    blocks = new ArrayList<Block>();
    kind = "assembly";
    // kind must still be set to something real,
    // and id also needs to be set
  }

  // construct a copy of the given assembly at (a,b,c)
  public Assembly( Assembly other, double a, double b, double c ) {
    currentId++;
    id = currentId;

    blocks = new ArrayList<Block>();
    kind = "assembly";
  }

  // construct and return assembly from input file
  public static Assembly build( Scanner input ) {
   
    String kind = input.next(); 

    int id = input.nextInt();   
    input.nextLine();

    if( kind.equals("stairs") ) {
      return new Stairs( id, input );
    }
    else if( kind.equals("hole") ) {
      return new Hole( id, input );
    }
    else if( kind.equals("door") ) {
      return new DoorFrame( id, input );
    }
    else { // all single block assemblies
      return new Single( kind, id, input );
    }

  }

  public void initId() {
    currentId++;
    id = currentId;
  }

  public ArrayList<Block> getBlocks() {
    return blocks;
  }

  public double getX() { return 0; }
  public double getY() { return 0; }
  public double getZ() { return 0; }

  // methods to override---------------------

  public void save( PrintWriter out ) {
  }

  public void move( double dx, double dy, double dz ) {
   
  }

  // rotate one notch either direction, if it can
  public void rotate( double amount ) {
  }

  // change size if can
  public void resize( double wx, double wy, double wz ) {
  }

  // move inner stuff if can
  public void moveInner( double dx, double dy, double dz ) {
  }

  public void resizeInner( double a, double b ) {
  }

  public void specialChangeInner( String s ) {
  }

  // make a copy of this assembly at (a,b,c)
  public Assembly copyAt( double a, double b, double c ) {
    return null;
  }

  // return whether any blocks of this assembly
  // touch (a,b,c)
  public boolean touches( double a, double b, double c ) {
    for( int k=0; k<blocks.size(); k++ ) {
      if( blocks.get(k).touches( a, b, c ) )
        return true;
    }
    return false;
  }

  public String getKind() {
    return kind;
  }

  // return when this assembly is hit by ray
  // a+lambda d for lambda >= 1
  // or lambda=-1 if not hit
  public double whenHitByRay( Triple a, Triple d ) {
    int whichBlock = -1;  // index of block that is hit by ray with
                          // lambda >= 1
    double firstLambda = -1;

    for( int k=0; k<blocks.size(); k++ ) {
        double[] lambdas = blocks.get(k).whenHitByRay( a, d );
        if ( lambdas[0] >= 1 ) {
            whichBlock = k;
            firstLambda = lambdas[0];
        }
    }

    if (whichBlock >= 0 ) {
       return firstLambda;
    }
    else
       return -1;
  }

  // return whether this assembly is hit by ray
  // a+lambda d for lambda > 1
  public boolean hitByRay( Triple a, Triple d ) {
    for( int k=0; k<blocks.size(); k++ ) {
      double[] lambdas = blocks.get(k).whenHitByRay( a, d );
      if( lambdas[0] > 1 )
        return true;
    }
    return false;
  }

  public void consoleDisplay() {
    System.out.println("id: " + id + " kind: " + kind );   
  }

  public int getId() {
    return id;
  }

  // depending on the kind of this assembly,
  // add its blocks to lists
  // (some blocks are created in Game, like Explorer, Bullet, Treasure,
  //  so don't get handled here)
  public void addBlocks( ArrayList<Block> fixed, ArrayList<Block> mobile ) {

    if( kind.equals("single") ) {// is really just the one block
      Block b = blocks.get(0);
      if( b.getKind().equals("Hunter") || b.getKind().equals("Mine") ) {
        mobile.add( b );
      }
      else {// all other single block kinds are fixed
        fixed.add( b );
      }
    }
    else if( kind.equals("stairs") ) {
      for( int k=0; k<blocks.size(); k++ ) {
        fixed.add( blocks.get(k) );
      }
    }
    else if( kind.equals("hole") ) {
      for( int k=0; k<blocks.size(); k++ ) {
        fixed.add( blocks.get(k) );
      }
    }
    else if( kind.equals("door") ) {
      for( int k=0; k<blocks.size(); k++ ) {
        fixed.add( blocks.get(k) );
      }
      // fancy thing for door:  put the door
      // block in mobile, since comes and goes
      // from reality
      Block door = ( (DoorFrame) this).getDoorBlock();
      if( door != null )
        mobile.add( door );
    }

  }// addBlocks

}
