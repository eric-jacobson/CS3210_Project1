import java.util.Scanner;

public class TryHops {
  public static void main(String[] args) {
    Scanner keys = new Scanner( System.in );
    System.out.print("enter v to explore: " );
    double v = keys.nextDouble();    
    for( int f=0; f<=90; f++ ) {
      System.out.println( f + ": " + (v*f - (16.0/900)*(f-1)*f ) );
    }
  }
}
