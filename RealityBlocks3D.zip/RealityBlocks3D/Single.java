/*  a Single is the simplest
kind of Assembly, only has one
block (stored, for uniformity,
in position 0 of blocks
*/

import java.util.Scanner;
import java.io.PrintWriter;

public class Single extends Assembly {

  // to read a single block assembly of given kind from
  // data file, just construct that block
  public Single( String knd, int ident, Scanner input ) {
    super();
System.out.println("constructing single with kind " + knd );
    kind = "single";   // kind of assembly
    id = ident;
    blocks.add( Block.build( knd, input ) );
  }

  public Single( Block b ) {
    super();
    initId();
    kind = "single";
    blocks.add( b );
  }

  public Single( Assembly oth, double a, double b, double c ) {
    super();
    initId();
    kind = "single";
    Single other = (Single) oth;
    blocks.add( Block.build( other.blocks.get(0), a, b, c ) );
  }

  public void save( PrintWriter out ) {
    Block b = blocks.get(0);  // get the one and only block
    // use b to save necessary info
    out.println( b.getKind().toLowerCase() + " " + id );
    b.save( out );
  }

  public void move( double dx, double dy, double dz ) {
    blocks.get(0).move( dx, dy, dz );
  }

  // rotate
  public void rotate( double amount ) {
    blocks.get(0).rotate( amount );
  }

  // change size if can
  public void resize( double wx, double wy, double wz ) {
    blocks.get(0).resize( wx, wy, wz );
  }

  public double getX() { return blocks.get(0).getX(); }
  public double getY() { return blocks.get(0).getY(); }
  public double getZ() { return blocks.get(0).getZ(); }

 public void consoleDisplay() {
   System.out.println("id: " + id );
   blocks.get(0).consoleDisplay();
  }

}// Single
