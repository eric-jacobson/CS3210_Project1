/*  
   Play in a game world
*/

import static org.lwjgl.glfw.GLFW.*;  // for key codes

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;

public class Game extends Basic
{
  private final static int SPACE = 30;  // space between player views

  public static double WORLDSIZE;   // world is a cube with this side length

  public static void main(String[] args)
  {
    if( args.length != 1 ){
      System.out.println("Usage:  j Game <world file name>");
      System.exit(1);
    }

    // this app uses two square view areas---one for each player's first person view
    final int windowHeight = 750;
    Game app = new Game( "Find the Treasure!", 30, 
                          2*windowHeight+SPACE, windowHeight, 30, args[0] );

    app.start();

  }// main

  // instance variables 

  // rather silly variables used to read from input file before
  // OpenGL context is available, used only in init to init camera3
  private double camX, camY, camZ, camAzi, camAlt;

  private Camera camera1, camera2;  // two first-person cameras

  private ArrayList<Block> fixed, mobile, arrivals, ghosts;

  private CellTable table;  // broad phase collision data structure

  private Soups fixedSoups, mobileSoups, ghostSoups;

  private Explorer player1, player2;  // blocks currently controlled by players

  private String gameStatus;
  private boolean treasureExploding;  

  private Camera splashCamera;
  private Soups splashSoups;
  
  private final static int splash1Pic = 21, splash2Pic = 22, splashBothPic = 23;

  // construct basic application with given title, pixel width and height
  // of drawing area, frames per second, and name of world data file
  public Game( String appTitle, int windowShift, int pw, int ph, int fps,
                    String worldFile )
  {
    super( appTitle, windowShift, pw, ph, (long) ((1.0/fps)*1000000000) );

    try{

      Pic.init();      // load all the textures
      Util.init();     // set up single large buffer for soup use

      Scanner input = new Scanner( new File( worldFile ) );

      WORLDSIZE = input.nextDouble();    // get world cube side length from file
      input.nextLine();  // toss comment

      // scan and toss data for 6 cameras and the cursor
      for (int k=0; k<7; k++) {
         input.nextLine();
      }

      input.nextInt();  input.nextLine();  // reading current assembly id and toss it

      input.nextLine();  // toss the ---- separator line

      // make empty list of assemblies, ready to load
      ArrayList<Assembly> assemblies = new ArrayList<Assembly>();

      // load assemblies from world file
 
      // first load the permanent assemblies
      int numPerm = input.nextInt();  input.nextLine();
      for( int k=0; k<numPerm; k++ ) {
        Assembly a = Assembly.build( input );
        assemblies.add( a ); 
      }

      // now load the editable assemblies
      int numEditable = input.nextInt();  input.nextLine();
      for( int k=0; k<numEditable; k++ ) {
        Assembly a = Assembly.build( input );
        assemblies.add( a ); 
      }

      // ---------------------------------------------------
      // now scan assemblies and build mobile and fixed lists of blocks

      fixed = new ArrayList<Block>();
      mobile = new ArrayList<Block>();

      for( int k=0; k<assemblies.size(); k++ ) {
        assemblies.get(k).addBlocks( fixed, mobile );
      }

      arrivals = new ArrayList<Block>();
      ghosts = new ArrayList<Block>();

      gameStatus = "playing";
      treasureExploding = false;

      // once and for all note fixed blocks in table
      table = new CellTable();

      for ( int k=0; k<fixed.size(); k++ ) {
         Block b = fixed.get(k);
         // System.out.println("about to note fixed block # " + k + " id = " + b.getId() +
         //          " of kind " + b.getKind() );
         table.registerFixed( b );
      }

      // System.out.println("hash table after registering fixed blocks:");
      // table.show();
      
    }// construct world from data file

    catch(Exception e){
      System.out.println("Something went wrong loading from file [" + 
                          worldFile + "]");
      e.printStackTrace();
      System.exit(1);
    }

  }

  // overriding Basic init, gets called by Basic.start 
  // after starting up OpenGL, right before main loop starts
  protected void init()
  {
    OpenGL.init();

    // activate all the textures
    for( int k=0; k<Pic.size(); k++ ){
      OpenGL.loadTexture( Pic.get(k) );
      System.out.println("activated texture number " + k );
    }

    OpenGL.setBackColor( 0, 0, 0 );

    final double viewSize = 0.1;
    final double viewDepth = 1.5;  // the smaller this is, the wider the perspective

    camera1 = new Camera( true, 1, 0, 0, 
      (getPixelWidth()-SPACE)/2, getPixelHeight(),        // viewport within pixel grid
      -viewSize, viewSize, -viewSize, viewSize, viewDepth*viewSize, 300,  // camera shape
                          0, 0, 0,  // irrelevant---Explorer sets its camera values
                          0, 0 );

    camera2 = new Camera( true, 1, SPACE + (getPixelWidth()-SPACE)/2, 0, 
      (getPixelWidth()-SPACE)/2, getPixelHeight(),        // viewport within pixel grid
      -viewSize, viewSize, -viewSize, viewSize, viewDepth*viewSize, 300,  // camera shape
                          0, 0, 0,  // irrelevant---Explorer sets its camera values
                          0, 0 );

    // construct the two Explorers:
    // *******************************************************
    player1 = new Explorer( 77, 59, 5, 180, 0, camera1 );
    player2 = new Explorer( 140, 130, 5, 90, 0, camera2 );
    // *******************************************************

     // put the objects in the list of all mobile blocks at the beginning:
     mobile.add( 0, player1 );
     mobile.add( 1, player2 );

    // construct the treasure block(s)
    // *******************************************************
    mobile.add( new Treasure( 110, 115, 180, 2, 1, 1 ) );
    // *******************************************************

    // construct hunters
    // *******************************************************
    mobile.add( new Hunter( 170, 170, 5, 270 ) );
    mobile.add( new Hunter( 60, 60, 5, 270 ) );
    mobile.add( new Hunter( 100, 100, 180, 270 ) );
    // *******************************************************

    // set up fixed for display once and for all
    fixedSoups = new Soups( Pic.size() );
    fixedSoups.add( fixed );
    fixedSoups.sortByTexture();

      // set up splash stuff once and for all

      // camera set similarly to Builder map view camera
      splashCamera = new Camera( false, -1, SPACE+ getPixelWidth()/4, 0,
                             (getPixelWidth()-SPACE)/2, getPixelHeight(),
                             -0.5, 0.5, -0.5, 0.5, 2, -2,
                             0, 0, 0,
                             0, 0 );

    ArrayList<Triangle> someTris = new ArrayList<Triangle>();

      // have two triangles for each of the three splash screens,
      // arranged in space with x from 0 to 1, 1 to 2, 2 to 3, y from 0 to 1, z at 0

      // player 1 wins
      someTris.add( new Triangle( new Vertex(0,0,0,0,0),
                                    new Vertex(1,0,0,1,0),
                                    new Vertex(1,1,0,1,1),       splash1Pic ) );
      someTris.add( new Triangle( new Vertex(0,0,0,0,0),
                                    new Vertex(1,1,0,1,1),
                                    new Vertex(0,1,0,0,1),       splash1Pic ) );
      // player 2 wins
      someTris.add( new Triangle( new Vertex(1,0,0,0,0),
                                    new Vertex(2,0,0,1,0),
                                    new Vertex(2,1,0,1,1),       splash2Pic ) );
      someTris.add( new Triangle( new Vertex(1,0,0,0,0),
                                    new Vertex(2,1,0,1,1),
                                    new Vertex(1,1,0,0,1),       splash2Pic ) );
      // both lose
      someTris.add( new Triangle( new Vertex(2,0,0,0,0),
                                    new Vertex(3,0,0,1,0),
                                    new Vertex(3,1,0,1,1),       splashBothPic ) );
      someTris.add( new Triangle( new Vertex(2,0,0,0,0),
                                    new Vertex(3,1,0,1,1),
                                    new Vertex(2,1,0,0,1),       splashBothPic ) );

      splashSoups = new Soups( Pic.size() );
      splashSoups.addTris( someTris );
      splashSoups.sortByTexture();

  }

  private static double amount = 1;  // distance to move per step

  private static int camAziAmount = 2;
  private static int camAltAmount = 2;

  protected void processInputs()
  {
    // process all waiting input events
    while( InputInfo.size() > 0 )
    {
      InputInfo info = InputInfo.get();

      if( info.kind == 'k' && (info.action == GLFW_PRESS || 
                               info.action == GLFW_REPEAT) )
      {
        int code = info.code, mods = info.mods;
                System.out.println("code: " + code + " mods: " + mods );

        // keys to control player1

          // changes that need to be supported

          if( code == GLFW_KEY_Z && mods==0 && player1 != null ) {
            player1.addRequest( new Request( "turn", 3 ) );
          }
          else if( code == GLFW_KEY_C && mods==0 && player1 != null ) {
            player1.addRequest( new Request( "turn", -3 ) );
          }
          else if( code == GLFW_KEY_S && mods==0 && player1 != null ) {
            player1.addRequest( new Request( "forward" ) );
          }
          else if( code == GLFW_KEY_X && mods==0 && player1 != null ) {
            player1.addRequest( new Request( "backward" ) );
          }
          else if( code == GLFW_KEY_LEFT_SHIFT && mods==1 && player1 != null ) {
            player1.addRequest( new Request( "cheatHop" ) );  // do a cheat hop
          }
          else if( code == GLFW_KEY_A && mods == 0 && player1 != null ) {// turn body a lot counterclockwise
            player1.turnToNext( true );
          }
          else if( code == GLFW_KEY_D && mods == 0 && player1 != null ) {// turn body a lot clockwise
            player1.turnToNext( false );
          }

          // changes that can be done immediately (say even when player is not supported)

          else if( code == GLFW_KEY_Q && mods == 0 && player1 != null ) {// tilt head down
            player1.tiltBy( -camAltAmount );
          }
          else if( code == GLFW_KEY_E && mods == 0 && player1 != null ) {// tilt head up
            player1.tiltBy( camAltAmount );
          }
          else if( code == GLFW_KEY_W && mods == 0 && player1 != null ) {// tilt head level
            player1.tiltTo( 0 );
            //            player1.turnHeadTo( 0 );
          }
          else if( code == GLFW_KEY_LEFT_CONTROL && mods == 2 && player1 != null ) {// fire
            // add bullet produced by player to arrivals
            arrivals.add( player1.fire() );
          }
          
        // keys to control player2

          // changes that need to be supported

          else if ( code == GLFW_KEY_KP_1 && mods==0 && player2 != null ) {
            player2.addRequest( new Request( "turn", 3 ) );
          }
          else if( code == GLFW_KEY_KP_3 && mods==0 && player2 != null ) {
            player2.addRequest( new Request( "turn", -3 ) );
          }
          else if( code == GLFW_KEY_KP_5 && mods==0 && player2 != null ) {
            player2.addRequest( new Request( "forward" ) );
          }
          else if( code == GLFW_KEY_KP_2 && mods==0 && player2 != null ) {
            player2.addRequest( new Request( "backward" ) );
          }
          else if( code == GLFW_KEY_RIGHT_SHIFT && mods==1 && player2 != null ) {
            player2.addRequest( new Request( "cheatHop" ) );  // do a cheat hop
          }
          else if( code == GLFW_KEY_KP_4 && mods == 0 && player2 != null ) {// turn body a lot counterclockwise
            player2.turnToNext( true );
          }
          else if( code == GLFW_KEY_KP_6 && mods == 0 && player2 != null ) {// turn body a lot clockwise
            player2.turnToNext( false );
          }

          // changes that can be done immediately (say even when player is not supported)

          else if( code == GLFW_KEY_KP_7 && mods == 0 && player2 != null ) {// tilt head down
            player2.tiltBy( -camAltAmount );
          }
          else if( code == GLFW_KEY_KP_9 && mods == 0 && player2 != null ) {// tilt head up
            player2.tiltBy( camAltAmount );
          }
          else if( code == GLFW_KEY_KP_8 && mods == 0 && player2 != null ) {// tilt head level
            player2.tiltTo( 0 );
            // player2.turnHeadTo( 0 );
          }
          else if( code == GLFW_KEY_RIGHT_CONTROL && mods == 2 && player2 != null ) {// fire
            // add bullet produced by player to arrivals
            arrivals.add( player2.fire() );
          }

      }// input event is a key

      else if ( info.kind == 'm' )
      {// mouse moved
      }

      else if( info.kind == 'b' )
      {// button action
      }// 'b' action

    }// loop to process all input events

  }// processInputs

   protected void update() {
  
      System.out.println("\n==================================================");
      System.out.println("Step # " + getStepNumber() );
      System.out.println("\n==================================================");

      ArrayList<Block> list;  // utility local variable for various uses

      // -------------------------------------------------------
      //  register all mobile blocks in table, with self as AABB, i.e., viewed as stationary
      //    We do this so arrivals will know about mobiles, too

      // System.out.println("\nRegister all mobile blocks, as if stationary:");

      for ( int k=0; k<mobile.size(); k++ ) {
         Block b = mobile.get(k);
         table.registerMobile( b.getAABB(), b );   
      }

      // table.show();

      // -------------------------------------------------------
      // give arrivals a chance to arrive (if there is
      // empty space in which to arrive)

      if (arrivals.size() > 0) {
         System.out.println("\narrivals:");
         for (int k=0; k<arrivals.size(); k++) {
            System.out.print( arrivals.get(k).getId() + " " );
         }
         System.out.println();
      }

      for (int k=0; k<arrivals.size(); k++) {
         Block checkee = arrivals.get(k);

         list = table.mightOverlap( checkee.getAABB(), checkee );

if (list.size() > 0) {
   System.out.println(checkee.getId() + " might overlap these: ");
   for (int j=0; j<list.size(); j++) {
      System.out.print( list.get(j).getId() + " " );
   }
   System.out.println();
}

         // now examine list to see if checkee actually would
         // overlap any block
         boolean overlaps = false;
   
         for (int j=0; !overlaps && j<list.size(); j++) {
            Block b = list.get(j);
            if (checkee.overlaps(b)) {
               System.out.println("actually does overlap " + b.getId() );
               System.out.println("arriving block is: " + checkee );
               System.out.println("overlapping block is: " + b );
               overlaps = true;
            }
         }

         if ( ! overlaps ) {// has free space to arrive, so 
                           // add to reality
            mobile.add( checkee );
System.out.println("adding " + checkee.getId() + " to mobiles");
            table.registerMobile( checkee.getAABB(), checkee );   

            // remove from arrivals
            arrivals.remove( k );
            k--;   // to avoid skipping next item
         }
         else {// can't arrive---something is in the way---so deal with according to kind
           if ( checkee.retriesArrival() ) {
              // just stay in arrival
           }
           else {// toss from arrivals, missed only chance to arrive
              arrivals.remove(k);
              k--;
           }
         }
      
      }// check arrival k for room to arrive

      // -------------------------------------------------------
      // determine whether each mobile is supported and adjust for gravity accordingly

      // System.out.println("\nsupport?");

      for (int k=0; k<mobile.size(); k++ ) {
         Block checkee = mobile.get(k);

         // System.out.println("checking support for mobile " + checkee.getId() );

         // expand in z direction a little so if supported will note shared cell
         // (if farther apart, grid cube border could separate two blocks
         list = table.mightOverlap( checkee.getAABB().zFluff(), checkee );

         // now examine list to see if checkee is supported
         boolean supported = false;

         for (int j=0; j<list.size() && !supported; j++ ) {
            Block b = list.get(j);

            // System.out.println("see if " + b.getId() + " supports");

            if (b.supports( checkee )) {
               supported = true;
               // System.out.println("found " + checkee.getId() + " is supported by " + b.getId() );
            }
         }
      
         checkee.setSupported( supported );  // note whether supported
         checkee.addRequest( new Request( "gravity" ) );

      }// loop to check supported for each mobile block

      // -------------------------------------------------------
      // give each mobile block a chance to behave
      for (int k=0; k<mobile.size(); k++) {
         Block b = mobile.get(k);
         if ( b.getKind().equals("Hunter") ) {
System.out.println("Behaving with hunter " + b );
            if ( player1 != null ) {
               if ( player2 != null ) {
                  ((Hunter) b).behave( player1, player2 );
               }
               else {
                  ((Hunter) b).behave( player1 );
               }
            }
            else {// player1 gone
               if ( player2 != null ) {
                  ((Hunter) b).behave( player2 );
               }
            }
         }
      }

      // -------------------------------------------------------
      // give each mobile block a chance to fulfill pending requests

      // System.out.println("\nfulfill requests");

      for (int k=0; k<mobile.size(); k++) {
         Block checkee = mobile.get(k);
         checkee.fulfillRequests();
      }// fulfill pending requests

      // -------------------------------------------------------
      // remove any ghosts that have counted down to 0
      for (int k=0; k<ghosts.size(); k++) {
         Block b = ghosts.get(k);
         if ( b.getCountdown() == 0 ) {
            ghosts.remove( k );
            k--;

            // detect end of game and shift splash camera

            if (b==player1) {// player 1 finished dieing
               player1 = null;
            }
            else if (b==player2) {// player 2 finished dieing  
               player2 = null;
            }
            else if (b.kind.equals("Treasure")) {// game is over---treasure done ghosting
               treasureExploding = false;

               if (gameStatus.equals("player1Wins")) {
                  splashCamera.shiftTo( 0.5, 0.5, 1 );
System.out.println("splash---1 wins");
               }
               else if (gameStatus.equals("player2Wins")) {
System.out.println("splash---2 wins");
                  splashCamera.shiftTo( 1.5, 0.5, 1 );
               }

            }// removing treasure---done exploding---see which player won

            // check for game over because both died
            if ( player1==null && player2==null ) {
System.out.println("splash---both lose");
               splashCamera.shiftTo( 2.5, 0.5, 1 );
               gameStatus = "bothLose";
            }

         }// block has reached end of countdown
      }// loop for all ghosts

      // -------------------------------------------------------
      // advance all mobile blocks for 1 time unit:
    
      double timeLeft = 1;   // time left in the 1 unit step

      while (timeLeft > 0.01 ) {// hard-coded tolerance---only occurrence of this constant
                                // Believe a 99% step won't be noticeable, anyway

         System.out.println("************************");
         System.out.println("\ntop of main loop, timeLeft = " + timeLeft );
         System.out.println("************************");

         // holds all pairs of blocks to check out with CCD
         ArrayList<BlockPair> pairs = new ArrayList<BlockPair>();

         table.clearMobiles();  // remove all mobile data each time do another partial time step
         
         // System.out.println("\nafter clear mobiles:");
         // table.show();

         // register all mobile blocks' swept volumes and gather possible collision pairs
         // for timeLeft

         for (int k=0; k<mobile.size(); k++) {
            table.registerMobiles( mobile.get(k), pairs, timeLeft );
         }

         // System.out.println("\nafter register all mobiles, swept:");
         // table.show();

         // for all possible collision pairs, determine time of first touch, if any,
         // thus determining tFirst = time of first collision = how long can advance all

         System.out.println("\npossible collision pairs:");
         for (int k=0; k<pairs.size(); k++) {
            System.out.print( pairs.get(k) + " " );
         }
         System.out.println();

         double tFirst = timeLeft;   //  (i.e., set tFirst to all remaining time)
         int winner = -1;  // possibly will be no collisions 

         for (int k=0; k<pairs.size(); k++) {
            BlockPair pair = pairs.get(k);
            Block a = pair.first;
            Block b = pair.second;

            // determine when (and whether) a and b collide
            
            double hitTime = Block.findHitTime( a, b, tFirst );

            System.out.println("hit time for " + a.getId() + " and " + b.getId() + " is " + hitTime );

            if (hitTime < 0) {// no hit within allotted amount of time
            }
            else {// have a collision for this pair within allotted time 
              
               if (hitTime < tFirst || winner == -1) {// have found an earlier collision
                                                      // or a first collision
                  tFirst = hitTime;
                  winner = k;  // current first collision pair   

System.out.println("Encountered actual hit");
System.out.println("block a is " + a );
System.out.println("block b is " + b );

               }

            }
               
         }// do CCD on pair k

         // advance all mobile blocks through tFirst time

         timeLeft -= tFirst;   // reduce total time available on step

         System.out.println("advance all mobiles through time " + tFirst );

         for (int k=0; k<mobile.size(); k++) {
            Block b = mobile.get(k);
            b.update( tFirst );

            // System.out.println("Block " + b.getId() + " now at center " + b.getX() + " " +
              //                   b.getY() + " " + b.getZ() +
                //                 " with vel = " + b.getVelocity() );
         }
 
         // handle first collision (if is one)
         if ( winner >= 0 ) {
            BlockPair pair = pairs.get(winner);
            Block a = pair.first, b = pair.second;
            System.out.println("handle first collision between " + a.getId() + " and " + b.getId() );
            handleCollision( a, b ); 
         }
 
      }// end of loop to advance time up to 1

      table.clearMobiles();  // getting ready for next update step

   }// update

  protected void display()
  {
    if ( gameStatus.equals("playing") || treasureExploding ) {

       // start with empty soups for mobile blocks
       if ( mobileSoups != null )
          mobileSoups.cleanup();
       mobileSoups = new Soups( Pic.size() );
   
       mobileSoups.add( mobile );
       mobileSoups.sortByTexture();
   
       // start with empty soups for ghost blocks
       if ( ghostSoups != null )
          ghostSoups.cleanup();
       ghostSoups = new Soups( Pic.size() );
   
       ghostSoups.add( ghosts );
       ghostSoups.sortByTexture();
   
       OpenGL.drawBackground();
   
       if ( player1 != null ) {// draw  player 1's view
          camera1.activate();
          fixedSoups.draw();
          mobileSoups.draw();
          ghostSoups.draw();
       }
   
       if ( player2 != null ) {// draw player 2's view
          camera2.activate();
          fixedSoups.draw();
          mobileSoups.draw();
          ghostSoups.draw();
       }

     }// playing

     else {
        OpenGL.drawBackground();
        splashCamera.activate();
        splashSoups.draw();
     }
 
   }// display

  // for all pairs of kinds of blocks handle
  // collision
  private void handleCollision( Block a, Block b ) {

     String aKind = a.getKind(), bKind = b.getKind();

     // note that either a is mobile and b is fixed, or
     // both are mobile

     if ( aKind.equals("Explorer") ) {

        if ( bKind.equals("Explorer") ) {
           collHandleStop( a );
           collHandleStop( b );
        }
        else if ( bKind.equals("Bullet") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Mine") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Hunter") ) {
           collHandleDie(a);
           collHandleStop(b);
        }
        else if ( bKind.equals("Door") || 
                  bKind.equals("Wall") ||
                  bKind.equals("Floor") ||
                  bKind.equals("GroundBox") ||
                  bKind.equals("SkyBox") ||
                  bKind.equals("Stair") 
                ) {
           collHandleStop( a );
        }
        else if ( bKind.equals("Treasure") ) { 
           if ( a == player1 ) {
              gameStatus = "player1Wins";
           }
           else {
              gameStatus = "player2Wins";
           }
           collHandleStop(a);
           collHandleDie(b); // treasure blows up for fun
           treasureExploding = true;
        }

        else {
           System.out.println("Huh?  Unknown kind of block [" + bKind + "]" );
           System.exit(1);
        }
     }// Explorer hits whatever

     else if ( aKind.equals("Bullet") ) {

        if ( bKind.equals("Explorer") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Bullet") ) {// unlikely, but can happen!
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Mine") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Hunter") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Door") || 
                  bKind.equals("Wall") ||
                  bKind.equals("Floor") ||
                  bKind.equals("GroundBox") ||
                  bKind.equals("SkyBox") ||
                  bKind.equals("Stair") ||
                  bKind.equals("Treasure") 
                ) {
           collHandleDie(a);
        }
        else {
           System.out.println("Huh?  Unknown kind of block [" + bKind + "]" );
           System.exit(1);
        }
     }

     // note:  Door should never hit anything---only arrives, leaves

     else if ( aKind.equals("Treasure") ) {
        if ( bKind.equals("Bullet") ) {
           collHandleDie(b);
        }
        else if ( bKind.equals("Explorer") ) {
           if ( b == player1 ) {
              gameStatus = "player1Wins";
           }
           else {
              gameStatus = "player2Wins";
           }
           collHandleDie(a); // treasure blows up for fun
           treasureExploding = true;
           collHandleStop(b);
        }
        else if ( bKind.equals("Door") ||
                  bKind.equals("Wall") ||
                  bKind.equals("Floor") ||
                  bKind.equals("GroundBox") ||
                  bKind.equals("SkyBox") ||
                  bKind.equals("Stair")
                ) {
           collHandleStop( a );
        }
        else if ( bKind.equals("Hunter") ) {
           collHandleStop( a );
           collHandleStop( b );
        }
 
        else {
           System.out.println("Huh?  Unknown kind of block [" + bKind + "]" );
           System.exit(1);
        }
 
     }

     else if ( aKind.equals("Mine") ) {

        if ( bKind.equals("Explorer") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Bullet") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Door") ||
                  bKind.equals("Wall") ||
                  bKind.equals("Floor") ||
                  bKind.equals("GroundBox") ||
                  bKind.equals("SkyBox") ||
                  bKind.equals("Stair") ||
                  bKind.equals("Mine") 
                ) {
           collHandleStop( a );
        }
        else if ( bKind.equals("Hunter") ) {
           collHandleStop( a );
           collHandleStop( b );
        }

        else {
           System.out.println("Huh?  Unknown kind of block [" + bKind + "]" );
           System.exit(1);
        }

     }// Mine

     else if ( aKind.equals("Hunter") ) {

        if ( bKind.equals("Explorer") ) {
           collHandleStop(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Bullet") ) {
           collHandleDie(a);
           collHandleDie(b);
        }
        else if ( bKind.equals("Door") ||
                  bKind.equals("Wall") ||
                  bKind.equals("Floor") ||
                  bKind.equals("GroundBox") ||
                  bKind.equals("SkyBox") ||
                  bKind.equals("Stair") ||
                  bKind.equals("Mine") ||
                  bKind.equals("Treasure")
                ) {
           collHandleStop( a );
        }
        else if ( bKind.equals("Hunter") ) {
           collHandleStop( a );
           collHandleStop( b );
        }

        else {
           System.out.println("Huh?  Unknown kind of block [" + bKind + "]" );
           System.exit(1);
        }

     }// Hunter

     else {
        System.out.println("Huh?  Unknown kind of mobile block [" + aKind + "]" );
        System.exit(1);
     }
     
  }

   // block a stops
   // (currently only for Explorers)
   private void collHandleStop( Block a ) {
      if (a.getKind().equals("Explorer") ) {
         ((Explorer) a).changeUpwardTo( 0 );
         ((Explorer) a).changeSpeedTo( 0 );
      }
      else if (a.getKind().equals("Treasure")) {
         a.setVelocity( Triple.zero );
      }
      else if (a.getKind().equals("Mine")) {
         a.setVelocity( Triple.zero );
      }
      else if (a.getKind().equals("Hunter")) {
         ((Hunter) a).changeUpwardTo( 0 );
         ((Hunter) a).changeSpeedTo( 0 );
      }
    
   }

  // block a dies
  private void collHandleDie( Block a ) {
     // first locate a in mobile:
     int loc = -1;
     for (int k=0; k<mobile.size() && loc < 0; k++) {
        if ( a == mobile.get(k) ) {
           loc = k;
        }
     }

     // now remove
     mobile.remove( loc );

     // and put in ghosts
     ghosts.add( a );
     
     // and set up so will keep track of how long to stay:
     a.becomeGhost();

  }// collHandleDie

}// Game
