/*  holds info for
   hashing a block and a
   grid cubelet that it touches
*/

public class HashInfo {

   public int i, j, k;
   public Block block;

   public HashInfo(int xCoord, int yCoord, int zCoord, Block b) {
      i = xCoord;  j = yCoord;  k = zCoord;
      block = b;
   }

   public String toString() {
      return "<" + i + " " + j + " " + k + " " + 
              block.getKind().substring(0,2) + " " + block.getId() + ">";
   }

   public boolean matchesLocation( HashInfo other ) {
      return i==other.i && j==other.j && k==other.k;
   }

}
