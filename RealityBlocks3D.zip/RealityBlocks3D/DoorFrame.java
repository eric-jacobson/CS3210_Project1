/*  a DoorFrame instance
consists of some wall blocks
arranged to form a door
*/

import java.util.Scanner;
import java.io.PrintWriter;

public class DoorFrame extends Assembly {

  private double x, y, z;  // reference point on assembly, for parallel to
                           // x-z plane case, is lower left corner
  private boolean leftRight;  // leftRight means wall runs
                              // parallel to x axis

  private double width;    // width of wall (in either x or y direction, depending on leftRight)
  private double height;   // height of wall (in z direction)
  private double thickness; // thickness of wall (x or y, depending on leftRight)

  private double holeWidth, holeHeight;  // size of hole
  private double horizOffset;  // offset of hole in wall

  private Door door;  

  public DoorFrame( int ident, Scanner input ) {
    super();  // just make empty container for blocks
    kind = "door";
    id = ident;

    // get all spec data from input:
    x = input.nextDouble(); y = input.nextDouble(); z = input.nextDouble();
    input.nextLine();
    int angle = input.nextInt();  input.nextLine();
      if( angle == 0 ) leftRight = false;  else leftRight = true;
    width = input.nextDouble(); height = input.nextDouble(); 
    thickness = input.nextDouble();
    input.nextLine();
    holeWidth = input.nextDouble();
    holeHeight = input.nextDouble();
    horizOffset = input.nextDouble();
    input.nextLine();

    createBlocks();

    // read details, build door block:
    String style = input.next();
    if( style.equals( "open" ) ) {// never have a door
      // nothing to do
      door = null;  // use to note is no alternation
    }
    else if( style.equals( "closed" ) ) {// always have a door
      // simply add the closed door as a normal block
      blocks.add( new Door( x+horizOffset+holeWidth/2, y, z+holeHeight/2,
                            holeWidth/2, thickness/2, holeHeight/2, -1, -1, -1, -1 ) );
    }
    else {// alternate
      // create and remember special door block
      double gap = 2*Util.collTol; // make sure door not seen to touch frame
      double t1 = input.nextInt(), t2 = input.nextInt(), t3 = input.nextInt(),
             t4 = input.nextInt();
      door = new Door( x+horizOffset+holeWidth/2, y, z+holeHeight/2,
                       holeWidth/2 - gap, thickness/2, holeHeight/2 - gap,
                       t1, t2, t3, t4 );
      input.nextLine();
      
    }
  }

  public DoorFrame( Assembly oth, double a, double b, double c ) {
    super();  // just make empty container for blocks
    initId();
    kind = "door";
    DoorFrame other = (DoorFrame) oth;

    // get all spec data from input:
    x = a;  y = b;  z = c;
    leftRight = other.leftRight;
    width = other.width;  height = other.height;
    thickness = other.thickness;
    holeWidth = other.holeWidth;
    holeHeight = other.holeHeight;
    horizOffset = other.horizOffset;

    createBlocks();

  }

  // create a default door at (a,b,c)
  public DoorFrame( double a, double b, double c ) {
    super();
    initId();
    kind = "door";

    x=a;  y=b;  z=c;
    leftRight = true;
    width = Wall.typWidth;  height = Wall.typHeight;
    thickness = Wall.typThickness;
    holeWidth = width/2;
    holeHeight = 0.75*height;
    horizOffset = width/4;

    createBlocks();
  }

  // from spec data, create the three blocks
  private void createBlocks() {

    blocks.clear();

    double cx, cy, cz, sx, sy, sz;  // convenient temp storage sometimes

    // brute force the two cases

    if( leftRight ) {// wall parallel to x-z plane

      // build block above the door hole
      sz = (height-holeHeight)/2;

      blocks.add( new Wall( x+horizOffset+holeWidth/2, y, z+holeHeight+sz,
         holeWidth/2, thickness/2, sz ) );        

      // build block to left of hole
      sx = horizOffset/2;
      blocks.add( new Wall( x+sx, y, z+height/2,
                            sx, thickness/2, height/2 ) ); 

      // build block to right of hole
      sx = (width-horizOffset-holeWidth)/2;
      blocks.add( new Wall( x+horizOffset+holeWidth+sx, y, z+height/2,
                          sx, thickness/2, height/2 ) );

    }
    else {// wall parallel to y-z plane

      // build block above the hole
      sz = (height-holeHeight)/2;
        blocks.add( new Wall( x, y+horizOffset+holeWidth/2, z+holeHeight+sz,
         thickness/2, holeWidth/2, sz ) );

      // build block to left of hole
      sy = horizOffset/2;
      blocks.add( new Wall( x, y+sy, z+height/2,
        thickness/2, sy, height/2 ) );

      // build block to right of hole
      sy = (width-horizOffset-holeWidth)/2;
        blocks.add( new Wall( x, y+horizOffset+holeWidth+sy, z+height/2,
          thickness/2, sy, height/2 ) );

    }

  }// createBlocks

  // NOTE:  when interactively change spec data, must keep door hole
  //        within the wall.  For example, must have horizOffset>=0,
  //        and horizOffset+holeWidth<=width, if a change would violate,
  //        don't do it

  public void save( PrintWriter out ) {
    out.println( "door" + " " + id);
    out.println( "   " + x + " " + y + " " + z );
    if( leftRight ) out.println( "  1" ); else out.println("  0" );
    out.println( "   " + width + " " + height + " " + thickness );
    out.println( "   " + holeWidth + " " + holeHeight + " " +
                  horizOffset );
    out.println("open");
  }

  public void move( double dx, double dy, double dz ) {
    x += dx; y += dy; z += dz;
    createBlocks();
  }

  // rotate one notch
  public void rotate( double amount ) {
    leftRight = ! leftRight;
    createBlocks();
  }

  // change size
  public void resize( double wx, double wy, double wz ) {
    if( width + wx > horizOffset + holeWidth ) width += wx;
    if( height + wz > holeHeight ) height += wz;
    if( thickness + wy > 0 ) thickness += wy;
    
    createBlocks();
  }

  public double getX() { return x; }
  public double getY() { return y; }
  public double getZ() { return z; }

  // move hole (only dx works)
  public void moveInner( double dx, double dy, double dz ) {
    boolean changed = false;

    if( 0 < horizOffset+dx && horizOffset+holeWidth+dx < width ) {
      horizOffset += dx;
      changed = true;
    }

    if( changed )
      createBlocks();
  }

  // change size of door by a in width, b in height
  public void resizeInner( double a, double b ) {
    boolean changed = false;
    if( 0 < holeWidth+a && horizOffset+holeWidth+a < width ) {
      holeWidth += a;
      changed = true;
    }
    if( 0 < holeHeight+b && holeHeight+b < height ) {
      holeHeight += b;
      changed = true;
    }
    if( changed )
      createBlocks();
  }

  public void consoleDisplay() {
     System.out.printf(
        "%s at %.2f %.2f %.2f width: %.2f height: %.2f thickness: %.2f " +
        " opening width: %.2f height: %.2f location: %.2f\n",
        kind, x, y, z, width, height, thickness, 
        holeWidth, holeHeight, horizOffset );
  }
 
  // produce the door block that fits inside
  // the hole in this door frame
  // without touching the frame (so it won't
  // be a hassle thinking there's something in the
  // way so it can't come into reality
  public Block getDoorBlock() {
    return door;
  }

}// DoorFrame
