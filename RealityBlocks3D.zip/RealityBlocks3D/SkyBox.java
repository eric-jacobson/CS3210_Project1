/* 
   skybox is used for border on world
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class SkyBox extends Block {

  // texture info for the 6 faces---shared over all SkyBox blocks
  private static int[] texs = {0,0,0,0,0,0,0,0};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  private static double[] scales = {200,200,200,200,200,200};  // each kind of block has its own texture
                                               // scaling

  public SkyBox( Scanner input ) {
    super( input );  // get location and size
    kind = "SkyBox";
    textures = SkyBox.texs;
    texScales = SkyBox.scales;
  }

}// SkyBox
