/*
  explorer is a kind of block
  that can be controlled by
  the player
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Explorer extends Block {

  // physical constants for explorer
  private static double SPEED = 1.0/6;  // 1/6 distance unit (foot) per frame (standard forward horizontal speed)
                                        // which at 30 fps is 5 feet per second
  private static double SPEEDLIMIT = 5*SPEED; 

  // After a lot of math, used TryHops to explore, got
       // (.5,2.0/27) works
  private static double DIAGVERTAMOUNT = 0.4;  // this is essentially the independent choice here
  private static double DIAGSPEED = 2.0/20.5;  // is simply 2 divided by # frames until vert velocity gets back down to 1

  private static double HOPAMOUNT = 0.1;  // impulse for purely vertical hop

  // texture info for the 6 faces---shared over all Explorer blocks
  private static int[] texs = {14,8};  // texture number available

  private static double[] scales = {2,2,2,2,2,2};  // each kind of block has its own texture
                                               // scaling

  private Camera camera;  // give access to the first person view camera

  // Explorer computes its vel from these
  // more manageable quantities:
  private double bodyAngle;  // body angle in x-y plane and speed give x-y plane velocity component
  private double speed;  
  private double upward;  // the z component of velocity, changed by hopping and gravity

  private double headAngle;  // how head is tilted

  private Mat4 rotMat;  // current rotation of head, updated in updateCamera

  // Explorer sizes of things
  public final static double bodyWidth = 1, bodyHeight = 2, headSize = 0.5;

  // sound effects
  private ClipInfo gunShot, blowUp;

  private double extraHorizVel;

  public Explorer( double ctrX, double ctrY, double ctrZ, double azi, double alt, Camera cam ) {
    super( "Explorer", ctrX, ctrY, ctrZ, bodyWidth, bodyWidth, bodyHeight );
    bodyAngle = azi;   // start off with body and camera and gun aimed along given direction
    headAngle = alt;
    textures = Explorer.texs;
    texScales = Explorer.scales;
    camera = cam;
    updateCamera();

    gunShot = new ClipInfo( "gunshot", "Sounds/gun.wav" );
    blowUp = new ClipInfo( "blow up", "Sounds/blowUp.wav" );

  }

  // update camera for first person
  // view from this explorer
  // positioned top center on face
  public void updateCamera() {
     rotMat = Mat4.rotate( bodyAngle, 0, 0, 1 ).mult( Mat4.rotate( headAngle, 0, -1, 0 ) );
     Triple camVec = new Triple( headSize, 0, headSize );
     Triple center = new Triple( cx, cy, cz+sz-headSize );  // center of head
     Triple camEye = center.add( rotMat.mult( camVec ) );

     camera.shiftTo( camEye.x, camEye.y, camEye.z );  // move
     camera.turnTo( bodyAngle );  // rotate
     camera.tiltTo( headAngle );  // tilt
  }

  // set vel from user-friendly data
  public void updateVelocity() {
    Triple horizVel = new Triple( Math.cos( Math.toRadians( bodyAngle ) ), 
                                  Math.sin( Math.toRadians( bodyAngle ) ), 0 );
    vel = horizVel.scalarProduct( speed ).add( new Triple(0,0,upward) );
  }

  // perform physics changes ========================================

  // turn body by amount
  public void turnBy( double amount ) {
    bodyAngle += amount;
    if( bodyAngle > 360 )  bodyAngle -= 360;
    if( bodyAngle < 0 ) bodyAngle += 360;
    updateCamera();
    updateVelocity();
  }

  // change bodyAngle to next multiple of Util.gridAngle
  // in ccw or cw direction
  // (needs bodyAngle in [0,360) to work correctly)
  public void turnToNext( boolean ccw ) {
     System.out.print("body angle changing from " + bodyAngle );
     int angle = (int) Math.round(bodyAngle);  // tidy up---should be integral, anyway

     if (ccw) {// turn big amount left
        bodyAngle = ( (angle/Util.gridAngle + 1) * Util.gridAngle ) % 360;
     }
     else {// turn big amount right
        if (angle <= 0) {// take care of 0 case--- 0 == 360, in a sense
           angle += 360;
        }
        bodyAngle = ( ( (angle - 1) / Util.gridAngle) * Util.gridAngle ) % 360;
     }

     updateCamera();
     updateVelocity();

     System.out.println(" to " + bodyAngle );

  }// turnToNext

  public void changeSpeedBy( double amount ) {
    if ( (speed + amount <= SPEEDLIMIT) &&
         (speed + amount >= -SPEEDLIMIT)
       ) {
       speed += amount;
       updateVelocity();
    }
    System.out.println("after change speed by, vel is now " + vel );
  }

  public void changeSpeedTo( double amount ) {
    speed = amount;
    updateVelocity();
    // System.out.println("vel is now " + vel );
  }

  public void changeUpwardTo( double amount ) {
    upward = amount;
    updateVelocity();
    // System.out.println("vel is now " + vel );
  }

  // set velocity to 0, using manageable parameters
  public void stop() {
    speed = 0;
    upward = 0;
    updateVelocity();
  }

  // tilt head
  public void tiltBy( double amount ) {
     double temp = headAngle + amount;
     if ( -89 <= temp && temp <= 89 ) {// valid tilt
        headAngle = temp;
        updateCamera();
     }
  }

  // tilt camera
  public void tiltTo( double amount ) {
    if ( -89 <= amount && amount <= 89 ) {
       headAngle = amount;
       updateCamera();
    }
  }

  public void verticalImpulse( double hop ) {
    upward += hop;   
    updateVelocity();
  }

  // update position of explorer over given time
  public void update( double time ) {
    super.update( time );

    updateCamera();
  }

  // perform requests for physics changes ==============================

  // fulfill all requests 
  // (subject to timing and attributes that may cause
  //  request to be put off or rejected)
  public void fulfillRequests() {

    super.fulfillRequests();  // do universal requests such as gravity

    // process remaining non-universal requests specially

    for( int k=0; k<requests.size(); k++ ) {
      Request req = requests.get(k);
      System.out.println("processing request " + req.kind );
      boolean remove = true;

      if( req.kind.equals( "turn" ) ) {
        if( supported )
          turnBy( req.amount );
      }
      else if( req.kind.equals( "forward" ) ) {
         if( supported ) {// if supported increment speed to a limit
           changeSpeedBy( SPEED );
         }
      }
      else if( req.kind.equals( "backward" ) ) {
         if( supported ) {// if supported decrement speed to a limit
           changeSpeedBy( -SPEED );
         }
      }
      else if( req.kind.equals( "hop" ) ) {// do a standard stair to stair hop
        upward = 0.4;  // peak at about 2.45 in 12 frames, reach height of 1 in about 21 frames
        speed = 2.0/21;  // horizontal speed to go 2 feet in 21 frames
        updateVelocity();
      }

      else if( req.kind.equals( "cheatHop" ) ) {// do complicated "cheat hop" if supported
        if ( req.elapsed == 0 // not in the middle of of a hop
             &&
             supported ) {// starting the cheat hop
            upward = 0.4;  // enough upward to peak at about 2.45 feet, which takes 12 frames
            // remember current horizontal velocity to add later in the cheat hop
            extraHorizVel = speed;
System.out.println("Remembering speed of " + speed );
            updateVelocity();
            remove = false;  // beginning a multi-frame cheat hop
        }
        else if( req.elapsed < 12 ){// travel purely upward until reach peak
          remove = false;  // continue multi-frame cheat hop
        }
        else if( req.elapsed == 12 ){// give horizontal impulse to travel 2 feet in 9 frames (until have dropped to net gain of 1')
          speed += 2.0/9 + extraHorizVel;
System.out.println("horiz vel is " + speed );
          updateVelocity();
          // last action for cheat hop, so let it be removed
        }

        req.elapsed++;  // no matter what state, increment frame counter

      }// cheat hop

      else if( req.kind.equals( "jump" ) ) {// do an honest jump adding some horizontal speed
        if( supported ) {
          upward = 0.5;    // tops out at 3.76 feet
          speed += 8.0/30;  // add horizontal speed that will travel 8 feet with given vertical velocity
          updateVelocity();
        }
      }

      // request is now removed (unless still pending)
      if( remove ) {
        requests.remove( k );
        k--;
      }

    }// process request k

  }// fulfillRequests

  // override usual Block draw method to draw
  // special triangles for an explorer
  public void draw( ArrayList<Triangle> list ) {
     if ( ! isGhost ) {// draw with special stuff

        Vertex v1, v2, v3;  // convenience
    
        // 4 body triangles forming a pyramid:
    
        // front face (index 0) --------------------
    
        v1 = new Vertex( cx-sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy-sy, cz-sz, 2*sx/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                          2*sx/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // right face (index 1) --------------------
    
        v1 = new Vertex( cx+sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy+sy, cz-sz, 2*sy/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                           2*sy/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // back face (index 2) --------------------
    
        v1 = new Vertex( cx+sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy+sy, cz-sz, 2*sx/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                           2*sx/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // left face (index 3) --------------------
    
        v1 = new Vertex( cx-sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy-sy, cz-sz, 2*sy/texScales[0], 0 );
        v3 = new Vertex( cx, cy, cz+sz, 
                           2*sy/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // draw the rotated head cube:
    
            // produce the 8 rotated and translated cube corner points (purely geometrical)
            Triple center = new Triple( cx, cy, cz + sz - headSize );
    
            // labeled by left/right, near/far, bottom/top
            Triple lnb = center.add( rotMat.mult( -headSize, -headSize, -headSize ) );
            Triple rnb = center.add( rotMat.mult( headSize, -headSize, -headSize ) );
            Triple lfb = center.add( rotMat.mult( -headSize, headSize, -headSize ) );
            Triple rfb = center.add( rotMat.mult( headSize, headSize, -headSize ) );
            Triple lnt = center.add( rotMat.mult( -headSize, -headSize, headSize ) );
            Triple rnt = center.add( rotMat.mult( headSize, -headSize, headSize ) );
            Triple lft = center.add( rotMat.mult( -headSize, headSize, headSize ) );
            Triple rft = center.add( rotMat.mult( headSize, headSize, headSize ) );
    
            // form all the triangles
            // (like default Block except use these 8 points instead of axis-aligned points)
    
            // front face (index 0) --------------------
        
            v1 = new Vertex( lnb, 
                                 0, 0 );
            v2 = new Vertex( rnb, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( rnt,
                              2*sx/texScales[0], 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lnb,
                                 0, 0 );
            v2 = new Vertex( rnt,
                                 2*sx/texScales[0], 2*sz/texScales[0] );
            v3 = new Vertex( lnt,
                                 0, 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // right face (index 1) --------------------
        
            v1 = new Vertex( rnb,
                                 0, 0 );
            v2 = new Vertex( rfb, 
                                 2*sy/texScales[1], 0 );
            v3 = new Vertex( rft,
                                 2*sy/texScales[1], 2*sz/texScales[1] );
            list.add( new Triangle( v1, v2, v3, textures[1] ) );
        
            v1 = new Vertex( rnb, 
                                 0, 0 );
            v2 = new Vertex( rft,
                                 2*sy/texScales[1], 2*sz/texScales[1] );
            v3 = new Vertex( rnt, 
                                 0, 2*sz/texScales[1] );
            list.add( new Triangle( v1, v2, v3, textures[1] ) );
        
            // back face (index 2) --------------------
        
            v1 = new Vertex( rfb, 
                                 0, 0 );
            v2 = new Vertex( lfb, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( lft,
                                 2*sx/texScales[0], 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( rfb, 
                                 0, 0 );
            v2 = new Vertex( lft,
                                 2*sx/texScales[0], 2*sz/texScales[0] );
            v3 = new Vertex( rft,
                                 0, 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // left face (index 3) --------------------
        
            v1 = new Vertex( lfb, 
                                 0, 0 );
            v2 = new Vertex( lnb, 
                                 2*sy/texScales[0], 0 );
            v3 = new Vertex( lnt,
                                 2*sy/texScales[0], 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lfb,
                                 0, 0 );
            v2 = new Vertex( lnt,
                                 2*sy/texScales[0], 2*sz/texScales[0] );
            v3 = new Vertex( lft,  
                                 0, 2*sz/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // top face (index 4) --------------------
        
            v1 = new Vertex( lnt, 
                                 0, 0 );
            v2 = new Vertex( rnt, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( rft, 
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lnt, 
                                 0, 0 );
            v2 = new Vertex( rft,
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            v3 = new Vertex( lft, 
                                 0, 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            // bottom face (index 5) --------------------
        
            v1 = new Vertex( lfb,
                                 0, 0 );
            v2 = new Vertex( rfb, 
                                 2*sx/texScales[0], 0 );
            v3 = new Vertex( rnb,
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );
        
            v1 = new Vertex( lfb, 
                                 0, 0 );
            v2 = new Vertex( rnb, 
                                 2*sx/texScales[0], 2*sy/texScales[0] );
            v3 = new Vertex( lnb, 
                                 0, 2*sy/texScales[0] );
            list.add( new Triangle( v1, v2, v3, textures[0] ) );

         }// draw specially
         else {
            super.draw( list );  // draw with random triangles
         }

  }// draw

  // if explorer goes through Gate, keeps trying forever
  // to arrive (hoping the block in the way will move)
  public boolean retriesArrival() {
    return true;
  }

  // fire weapon by creating a bullet with
  // suitable position and velocity
  public Bullet fire() {

     gunShot.play(false);

     Triple center = camera.getLocation();
     Triple dir = camera.getDirection(); // gun is aimed along camera direction which is length 1

     Triple pos = center.pointOnLine( 1.5, dir );

     Bullet bullet = new Bullet( pos.x, pos.y, pos.z, dir.scalarProduct( 4.0 ) );

System.out.println("Firing bullet with id " + bullet.getId() + " from position " + 
                   pos + " with velocity " + dir.scalarProduct( 10 )  );

     return bullet;
  }

  protected void becomeGhost() {
     super.becomeGhost();
     blowUp.play(false);
     countdown = 30;
  }

}// Explorer
