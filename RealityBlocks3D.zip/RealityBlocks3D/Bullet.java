/*
  bullet is a kind of block
  that is shot by Bullet, others,
  explodes when hits anything,
  mostly destroying that thing,
  if it is mobile and not too tough
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Bullet extends Block {

  public final static double size = 0.1;  

  // texture info for the 6 faces---shared over all Bullet blocks
  private static int[] texs = {11,11,11,11,11,11};  // texture number for each face in standard order
                                               // front, right, back, left, top, bottom

  private static double[] scales = {1,1,1,1,1,1};  // each kind of block has its own texture
                                               // scaling

  private ClipInfo explosion;

  // construct standard size bullet at given location with given velocity v
  public Bullet( double ctrX, double ctrY, double ctrZ, Triple v ) {
    super( "Bullet", ctrX, ctrY, ctrZ, size, size, size );
    vel = v;
    textures = Bullet.texs;
    texScales = Bullet.scales;

    explosion = new ClipInfo("explosion", "Sounds/explosion.wav" );
  }

  // note that Bullet uses ordinary Block draw method

  protected void becomeGhost() {
     super.becomeGhost();

     explosion.play(false);

     countdown = 10;
  }

}// Bullet
