public class CreateKeyDocument {

   public static void main( String[] args ) {

      System.out.println("%  Player 1 keys");

      key( 8, 3, "Z", "\\stt turn left $\\ss 3^\\circ$", 3, 3 );
      key( 11, 3, "X", "\\stt slow down", 3, 3 );
      key( 14, 3, "C", "\\stt turn right $\\ss 3^\\circ$", 3, 3 );

      key( 6.5, 6, "A", "\\stt turn left $\\ss 15^\\circ$", 3, 3 );
      key( 9.5, 6, "S", "\\stt speed up", 3, 3 );
      key( 12.5, 6, "D", "\\stt turn right $\\ss 15^\\circ$", 3, 3 );

      key( 5, 9, "Q", "\\stt tilt down", 3, 3 );
      key( 8, 9, "W", "\\stt no tilt", 3, 3 );
      key( 11, 9, "E", "\\stt tilt up", 3, 3 );

      key( 0, 0, "control", "\\stt fire", 5, 3 );
      key( 0, 3, "shift", "\\stt jump", 8, 3 );

      System.out.println("%  Player 2 keys");

      key( 27, 3, "1", "\\stt turn left $\\ss 3^\\circ$", 3, 3 );
      key( 30, 3, "2", "\\stt slow down", 3, 3 );
      key( 33, 3, "3", "\\stt turn right $\\ss 3^\\circ$", 3, 3 );

      key( 27, 6, "4", "\\stt turn left $\\ss 15^\\circ$", 3, 3 );
      key( 30, 6, "5", "\\stt speed up", 3, 3 );
      key( 33, 6, "6", "\\stt turn right $\\ss 15^\\circ$", 3, 3 );

      key( 27, 9, "7", "\\stt tilt down", 3, 3 );
      key( 30, 9, "8", "\\stt no tilt", 3, 3 );
      key( 33, 9, "9", "\\stt tilt up", 3, 3 );

      key( 18, 0, "control", "\\stt fire", 5, 3 );
      key( 15, 3, "shift", "\\stt jump", 8, 3 );
   }

   private static void key( double x, double y,
                            String lllabel, String mainLabel,
                            double w, double h ) { 
     final double smidge = 0.25;
     System.out.println("\\putrectangle corners at " + x + " " + y + 
                         " and " + 
                           (x+w) + " " + (y+h) );
     System.out.println("\\put {" + lllabel + "} [bl] at " + 
                           (x+smidge) + " " + (y+smidge) );
     System.out.println("\\put {" + mainLabel + "} [b] at " +
                           (x+w/2) + " " + (y+2*h/3) );
   }

}
