/*  a Stairs instance
consists of collection of step
blocks
*/

import java.util.Scanner;
import java.io.PrintWriter;

public class Stairs extends Assembly {

  // info to specify stairs
  private int numSteps;

  private double x, y, z;  // location of center of bottom step
  private double angle;  // rotation about z axis of staircase
                         // angle==0 has bottom step at origin, top step
                         // out along +x axis

  private double stepWidth;    // width of each step
  private static double stepDepth = 1;   // unchangeable half depth of each step
  private static double stepThickness = 0.5; // unchangeable half thickness of each step

  private double rise;  // z distance of whole staircase
  private double run;  // x or y distance (depends on angle) of staircase

  // build stairs from input file
  public Stairs( int ident, Scanner input ) {
    super();  // just make empty blocks
    kind = "stairs";
    id = ident;

    // get all spec data from input:
    numSteps = input.nextInt(); input.nextLine();
    x = input.nextDouble(); y = input.nextDouble(); z = input.nextDouble();
    input.nextLine();
    angle = input.nextDouble();  input.nextLine();
    stepWidth = input.nextDouble(); 
    input.nextLine();

    createBlocks();
  }

  // build typical stairs at specified location
  public Stairs( double a, double b, double c ) {
    super();
    initId();
    kind = "stairs";
    numSteps = 8;
    x=a;  y=b;  z=c;
    angle = 0;
    stepWidth = Stair.typWidth;
    createBlocks();
  }

  // build a copy of other stairs at (a,b,c)
  public Stairs( Assembly oth, double a, double b, double c ) {
    super();  // just make empty blocks
    initId();

    kind = "stairs";
    Stairs other = (Stairs) oth;

    // get all spec data from input:
    numSteps = other.numSteps;
    x = a;  y = b;  z = c;
    angle = other.angle;
    stepWidth = other.stepWidth;

    createBlocks();
  }

  // from spec data, create all the steps
  private void createBlocks() {

    blocks.clear();

    double a=x, b=y, c=z;  // (a,b,c) will scan over all center points

    // vector along direction of staircase from bottom to top
    double dx = Math.cos( Math.toRadians( angle ) );
    double dy = Math.sin( Math.toRadians( angle ) );
    // vector looking perp to the left when going up the stairs
    double px = -dy, py = dx;

    double drun = 2;       // used to be:  2*run/(numSteps-1);
    double drise = 1;      // used to be:  2*rise/(numSteps-1);

    for( int k=0; k<numSteps; k++ ) {
      // make step with center at a,b,c
      blocks.add( new Stair( a, b, c, 
                             Math.abs(dx*stepDepth+dy*stepWidth), 
                             Math.abs(dx*stepWidth+dy*stepDepth),
                             stepThickness ) );
      // move a,b,c to new position
      a += drun*dx;  b += drun*dy;  c += drise;

    }

  }
  
  public void save( PrintWriter out ) {
    out.println( "stairs" + " " + id );
    out.println( "   " + numSteps );
    out.println( "   " + x + " " + y + " " + z );
    out.println( "   " + angle );
    out.println( "   " + stepWidth );
  }

  public void move( double dx, double dy, double dz ) {
    x += dx; y += dy; z += dz;
    createBlocks();
  }

  // rotate one notch positive or negative direction
  public void rotate( double amount ) {
    if( amount > 0 ) {
      angle += 90;
      if( angle == 360 ) 
        angle = 0;
    }
    else {
      angle -= 90;
      if( angle == -90 ) 
        angle = 270;
    }
    createBlocks();
  }

  // change size 
  public void resize( double wx, double wy, double wz ) {
    if( stepWidth + wy > 0 ) stepWidth += wy;

    createBlocks();
  }

  public void specialChangeInner( String s ) {
    if( s.equals("fewer") && numSteps > 1 ) {
      numSteps--;
      createBlocks(); 
    }
    else if( s.equals("more") ) {
      numSteps++;
      createBlocks(); 
    }
  }

  public double getX() { return x; }
  public double getY() { return y; }
  public double getZ() { return z; }

  public void consoleDisplay() {
    System.out.printf(
        "%s at %.2f %.2f %.2f number of steps: %d step width: %.2f\n", 
        kind, x, y, z, numSteps, 2*stepWidth );
  }
 
}// Stairs
