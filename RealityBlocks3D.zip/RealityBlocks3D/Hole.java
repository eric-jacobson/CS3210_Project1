/*  a Hole instance
consists of some wall blocks
arranged to form a hole
*/

import java.util.Scanner;
import java.io.PrintWriter;

public class Hole extends Assembly {

  private double x, y, z;  // reference point on assembly, for parallel to
                           // x-z plane case, is lower left corner
  private boolean leftRight;  // leftRight means wall runs
                              // parallel to x axis

  private double width;    // width of wall (in either x or y direction, depending on leftRight)
  private double height;   // height of wall (in z direction)
  private double thickness; // thickness of wall (x or y, depending on leftRight)

  private double holeWidth, holeHeight;  // size of hole
  private double horizOffset, vertOffset;  // offset of hole in wall

  public Hole( int ident, Scanner input ) {
    super();  // just make empty container for blocks
    kind = "hole";
    id = ident;

    // get all spec data from input:
    x = input.nextDouble(); y = input.nextDouble(); z = input.nextDouble();
    input.nextLine();
    int angle = input.nextInt();  input.nextLine();
      if( angle == 0 ) leftRight = false;  else leftRight = true;
    width = input.nextDouble(); height = input.nextDouble(); 
    thickness = input.nextDouble();
    input.nextLine();
    holeWidth = input.nextDouble();
    holeHeight = input.nextDouble();
    horizOffset = input.nextDouble();
    vertOffset = input.nextDouble();
    input.nextLine();

    createBlocks();
  }

  public Hole( Assembly oth, double a, double b, double c ) {
    super();  // just make empty container for blocks
    initId();
    kind = "hole";
    Hole other = (Hole) oth;

    // get all spec data from input:
    x = a;  y = b;  z = c;
    leftRight = other.leftRight;
    width = other.width;  height = other.height;
    thickness = other.thickness;
    holeWidth = other.holeWidth;
    holeHeight = other.holeHeight;
    horizOffset = other.horizOffset;
    vertOffset = other.vertOffset;

    createBlocks();

  }

  // create a default hole at (a,b,c)
  public Hole( double a, double b, double c ) {
    super();
    initId();
    kind = "hole";

    x=a;  y=b;  z=c;
    leftRight = true;
    width = Wall.typWidth;  height = Wall.typHeight;
    thickness = Wall.typThickness;
    holeWidth = width/2;
    holeHeight = height/2;
    horizOffset = width/4;
    vertOffset = height/4;

    createBlocks();
  }

  // from spec data, create all the steps
  private void createBlocks() {

    blocks.clear();

    double cx, cy, cz, sx, sy, sz;  // convenient temp storage sometimes

    // brute force the two cases

    if( leftRight ) {// wall parallel to x-z plane

      // build block above the hole (if is one)
      sz = (height-holeHeight-vertOffset)/2;

      if( sz > 0 ) {
        blocks.add( new Wall( x+horizOffset+holeWidth/2, y, z+vertOffset+holeHeight+sz,
                              holeWidth/2, thickness/2, sz ) );        
      }      

      // build block below the hole (if is one)
      sz = vertOffset/2;
      if( sz > 0 ) {
        blocks.add( new Wall( x+horizOffset+holeWidth/2, y, z+sz,
                             holeWidth/2, thickness/2, sz ) );
      } 

      // build block to left of hole (if is one)
      sx = horizOffset/2;
      if( sx > 0 ) {
        blocks.add( new Wall( x+sx, y, z+height/2,
                              sx, thickness/2, height/2 ) ); 
      }

      // build block to right of hole (if is one)
      sx = (width-horizOffset-holeWidth)/2;
      if( sx > 0 ) {
        blocks.add( new Wall( x+horizOffset+holeWidth+sx, y, z+height/2,
                              sx, thickness/2, height/2 ) );
      }

    }
    else {// wall parallel to y-z plane

      // build block above the hole (if is one)
      sz = (height-holeHeight-vertOffset)/2;
      if( sz > 0 ) {
        blocks.add( new Wall( x, y+horizOffset+holeWidth/2, z+vertOffset+holeHeight+sz,
         thickness/2, holeWidth/2, sz ) );
      }

      // build block below the hole (if is one)
      sz = vertOffset/2;
      if( sz > 0 ) {
        blocks.add( new Wall( x, y+horizOffset+holeWidth/2, z+sz,
          thickness/2, holeWidth/2, sz ) );
      }

      // build block to left of hole (if is one)
      sy = horizOffset/2;
      if( sy > 0 ) {
        blocks.add( new Wall( x, y+sy, z+height/2,
          thickness/2, sy, height/2 ) );
      }

      // build block to right of hole (if is one)
      sy = (width-horizOffset-holeWidth)/2;
      if( sy > 0 ) {
        blocks.add( new Wall( x, y+horizOffset+holeWidth+sy, z+height/2,
          thickness/2, sy, height/2 ) );
      }

    }

  }// createBlocks

  // NOTE:  when interactively change spec data, must keep hole
  //        within the wall.  For example, must have horizOffset>=0,
  //        and horizOffset+holeWidth<=width, if a change would violate,
  //        clamp exactly to border

  public void save( PrintWriter out ) {
    out.println( "hole" + " " + id);
    out.println( "   " + x + " " + y + " " + z );
    if( leftRight ) out.println( "  1" ); else out.println("  0" );
    out.println( "   " + width + " " + height + " " + thickness );
    out.println( "   " + holeWidth + " " + holeHeight + " " +
                  horizOffset + " " + vertOffset );
  }

  public void move( double dx, double dy, double dz ) {
    x += dx; y += dy; z += dz;
    createBlocks();
  }

  // rotate one notch
  public void rotate( double amount ) {
    leftRight = ! leftRight;
    createBlocks();
  }

  // change size
  public void resize( double wx, double wy, double wz ) {
    if( width+wx > 0 && horizOffset+holeWidth < width+wx ) width += wx;
    if( height+wz > 0 && vertOffset+holeHeight < height+wz ) height += wz;
    if( thickness + wy > 0 ) thickness += wy;
    
    createBlocks();
  }

  public double getX() { return x; }
  public double getY() { return y; }
  public double getZ() { return z; }

  // move hole
  public void moveInner( double dx, double dy, double dz ) {
    boolean changed = false;

    if( 0 < horizOffset+dx && horizOffset+holeWidth+dx < width ) {
      horizOffset += dx;
      changed = true;
    }

    System.out.println("vert+height+dz: " + (vertOffset+holeHeight+dz) );

    if( 0 < vertOffset+dz && vertOffset+holeHeight+dz < height ) {
      vertOffset += dz;
      changed = true;
    }

    if( changed )
      createBlocks();
  }

  // change size of hole by a in width, b in height
  public void resizeInner( double a, double b ) {
    boolean changed = false;
    if( 0 < holeWidth+a && horizOffset+holeWidth+a < width ) {
      holeWidth += a;
      changed = true;
    }
    if( 0 < holeHeight+b && vertOffset+holeHeight+b < height ) {
      holeHeight += b;
      changed = true;
    }
    if( changed )
      createBlocks();
  }

public void consoleDisplay() {
   System.out.printf(
     "%s at %.2f %.2f %.2f width: %.2f height: %.2f thickness: %.2f " +
      "hole width: %.2f height: %.2f location: %.2f %.2f\n",
     kind, x, y, z, width, height, thickness, holeWidth, holeHeight,
     horizOffset, vertOffset );
}
 
}// Hole
