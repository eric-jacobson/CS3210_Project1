/*  block implements all objects in the
world, different kinds of blocks have
different face textures, behaviors, and
so on
*/

import java.util.Scanner;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Block {

  protected static double eps = Util.collTol; // just for typing convenience

  private static int nextId = 0;

  private int id;

  protected String kind;  // kind of block (for convenience to avoid need to use
                        // reflection)

  protected double cx, cy, cz;  //  current center point of the block
  protected double sx, sy, sz;  // size of block---never changes for a specific
                              // block instance

  protected Triple vel;  // current translational velocity for this block
  // other physics stuff will be added later:

  // texture info for the 6 faces
  protected int[] textures;  // texture number for each face in standard order
                           // front, right, back, left, top, bottom
  protected double[] texScales;  // each kind of block has its own texture
                               // scaling

  protected ArrayList<Request> requests;

  // universal attributes
  protected boolean supported;

   // know whether is a ghost and what step on
   protected int NUMGHOSTTRIS = 12;
   protected boolean isGhost; 
   protected int countdown;
  
  // build a block from data file
  public Block( Scanner input ) {

    nextId++;  id = nextId;

    // get shared info:  location and size
    cx = input.nextDouble(); cy = input.nextDouble(); cz = input.nextDouble();
    input.nextLine();
    sx = input.nextDouble(); sy = input.nextDouble(); sz = input.nextDouble();
    input.nextLine();

    kind = "Block";  // if ever see this kind unchanged, something is wrong!
    vel = Triple.zero;

    requests = new ArrayList<Request>();

    isGhost = false;
    // countdown irrelevant until becomes ghost

  }

  public Block( String knd, double ctrX, double ctrY, double ctrZ,
                double sizeX, double sizeY, double sizeZ ) {

    nextId++;  id = nextId;

    kind = knd;
    cx = ctrX;  cy = ctrY;  cz = ctrZ;  
    sx = sizeX; sy = sizeY; sz = sizeZ;
    vel = Triple.zero;
    requests = new ArrayList<Request>();
  }

  // construct copy of other with center changed to (a,b,c)
  public Block( Block other, double a, double b, double c ) {

    nextId++;  id = nextId;

    kind = other.kind;
    cx = a;  cy = b;  cz = c;  
    sx = other.sx; sy = other.sy; sz = other.sz; 
    vel = Triple.zero;
    requests = new ArrayList<Request>();
  }

  // given kind of block, build one using input
  // (could use reflection to do this more nicely,
  //  but let's not bother)
  public static Block build( String knd, Scanner input ) {
    if( knd.equals("wall") )
      return new Wall( input );
    else if( knd.equals("floor") )
      return new Floor( input );
    else if( knd.equals("mine") )
      return new Mine( input );
    else if( knd.equals("skybox") )
      return new SkyBox( input );
    else if( knd.equals("groundbox") )
      return new GroundBox( input );
    else {
      System.out.println("kind " + knd + " not handled in Block.build, error");
      System.exit(1);
      return null;
    }
    
  }// build

  // build a copy of existing block
  // (skybox and groundbox not implemented since we
  //  don't copy them)
  public static Block build( Block other, double a, double b, double c ) {
    if( other.kind.equals("Wall") ) 
      return new Wall( (Wall) other, a, b, c );
    else if( other.kind.equals("Floor") ) 
      return new Floor( (Floor) other, a, b, c );
    else if( other.kind.equals("Mine") ) 
      return new Mine( (Mine) other, a, b, c );
    else
      return null;
  }

  // "draw" by adding 12 triangles for this block to the
  // given list,
  // unless is a ghost
  public void draw( ArrayList<Triangle> list ) {

     Vertex v1, v2, v3;  // convenience

     if ( ! isGhost ) {

        // front face (index 0) --------------------

        v1 = new Vertex( cx-sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy-sy, cz-sz, 2*sx/texScales[0], 0 );
        v3 = new Vertex( cx+sx, cy-sy, cz+sz, 
                      2*sx/texScales[0], 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );

        v1 = new Vertex( cx-sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy-sy, cz+sz, 
                       2*sx/texScales[0], 2*sz/texScales[0] );
        v3 = new Vertex( cx-sx, cy-sy, cz+sz, 0, 2*sz/texScales[0] );
        list.add( new Triangle( v1, v2, v3, textures[0] ) );
    
        // right face (index 1) --------------------
    
        v1 = new Vertex( cx+sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy+sy, cz-sz, 2*sy/texScales[1], 0 );
        v3 = new Vertex( cx+sx, cy+sy, cz+sz, 
                           2*sy/texScales[1], 2*sz/texScales[1] );
        list.add( new Triangle( v1, v2, v3, textures[1] ) );
    
        v1 = new Vertex( cx+sx, cy-sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy+sy, cz+sz, 
                           2*sy/texScales[1], 2*sz/texScales[1] );
        v3 = new Vertex( cx+sx, cy-sy, cz+sz, 0, 2*sz/texScales[1] );
        list.add( new Triangle( v1, v2, v3, textures[1] ) );
    
        // back face (index 2) --------------------
    
        v1 = new Vertex( cx+sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy+sy, cz-sz, 2*sx/texScales[2], 0 );
        v3 = new Vertex( cx-sx, cy+sy, cz+sz, 
                           2*sx/texScales[2], 2*sz/texScales[2] );
        list.add( new Triangle( v1, v2, v3, textures[2] ) );
    
        v1 = new Vertex( cx+sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy+sy, cz+sz, 
                           2*sx/texScales[2], 2*sz/texScales[2] );
        v3 = new Vertex( cx+sx, cy+sy, cz+sz, 0, 2*sz/texScales[2] );
        list.add( new Triangle( v1, v2, v3, textures[2] ) );
    
        // left face (index 3) --------------------
    
        v1 = new Vertex( cx-sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy-sy, cz-sz, 2*sy/texScales[3], 0 );
        v3 = new Vertex( cx-sx, cy-sy, cz+sz, 
                           2*sy/texScales[3], 2*sz/texScales[3] );
        list.add( new Triangle( v1, v2, v3, textures[3] ) );
    
        v1 = new Vertex( cx-sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx-sx, cy-sy, cz+sz, 
                           2*sy/texScales[3], 2*sz/texScales[3] );
        v3 = new Vertex( cx-sx, cy+sy, cz+sz, 0, 2*sz/texScales[3] );
        list.add( new Triangle( v1, v2, v3, textures[3] ) );
    
        // top face (index 4) --------------------
    
        v1 = new Vertex( cx-sx, cy-sy, cz+sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy-sy, cz+sz, 2*sx/texScales[4], 0 );
        v3 = new Vertex( cx+sx, cy+sy, cz+sz, 
                           2*sx/texScales[4], 2*sy/texScales[4] );
        list.add( new Triangle( v1, v2, v3, textures[4] ) );
    
        v1 = new Vertex( cx-sx, cy-sy, cz+sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy+sy, cz+sz, 
                           2*sx/texScales[4], 2*sy/texScales[4] );
        v3 = new Vertex( cx-sx, cy+sy, cz+sz, 0, 2*sy/texScales[4] );
        list.add( new Triangle( v1, v2, v3, textures[4] ) );
    
        // bottom face (index 5) --------------------
    
        v1 = new Vertex( cx-sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy+sy, cz-sz, 2*sx/texScales[5], 0 );
        v3 = new Vertex( cx+sx, cy-sy, cz-sz, 
                           2*sx/texScales[5], 2*sy/texScales[5] );
        list.add( new Triangle( v1, v2, v3, textures[5] ) );
    
        v1 = new Vertex( cx-sx, cy+sy, cz-sz, 0, 0 );
        v2 = new Vertex( cx+sx, cy-sy, cz-sz, 
                           2*sx/texScales[5], 2*sy/texScales[5] );
        v3 = new Vertex( cx-sx, cy-sy, cz-sz, 0, 2*sy/texScales[5] );
        list.add( new Triangle( v1, v2, v3, textures[5] ) );
     }
     else {// draw as a ghost

        // generate some random triangles around center using textures
        for (int k=0; k<NUMGHOSTTRIS; k++) {
           int index = Util.rng.nextInt( textures.length ); // which texture to use

           v1 = new Vertex( Util.randomPoint( cx, cy, cz, 3*sx, 3*sy, 3*sz ), 
                             0, 0 );
           v2 = new Vertex( Util.randomPoint( cx, cy, cz, 3*sx, 3*sy, 3*sz ), 
                             2*sx/texScales[index], 0 );
           v3 = new Vertex( Util.randomPoint( cx, cy, cz, 3*sx, 3*sy, 3*sz ), 
                             2*sx/texScales[index], 2*sy/texScales[index] );

           list.add( new Triangle( v1, v2, v3, textures[index] ) );
           
        }// kth random triangle

        // manage ghostliness
        countdown--;

     }

  }// draw

  // save basic info for this block to output file
  public void save( PrintWriter out ) {
    out.println( "   " + cx + " " + cy + " " + cz );
    out.println( "   " + sx + " " + sy + " " + sz );
  }

  public void move( double dx, double dy, double dz ) {
    cx += dx; cy += dy; cz += dz;
  }

  // rotate one notch (amount is ignored)
  public void rotate( double amount ) {
    double temp = sx;
    sx = sy;
    sy = temp;
  }

  // change size
  public void resize( double wx, double wy, double wz ) {
    if( sx + wx > 0 ) sx += wx;
    if( sy + wy > 0 ) sy += wy;
    if( sz + wz > 0 ) sz += wz;
  }

  public String getKind() {
    return kind;
  }

  public double getX() { return cx; }
  public double getY() { return cy; }
  public double getZ() { return cz; }

   public Triple getVelocity() {
      return vel;
   }

  public void update( double time ) {
    cx += time * vel.x;
    cy += time * vel.y;
    cz += time * vel.z;
  }

  // return whether (a,b,c) touches
  // this box
  public boolean touches( double a, double b, double c ) {
    return  cx-sx <= a && a <= cx+sx &&
            cy-sy <= b && b <= cy+sy &&
            cz-sz <= c && c <= cz+sz;
  }

  // compute [lambdaIn,lambdaOut] for lambdas for which
  // ray a+lambda d hits this block
  // (use -1 to signal never found entry/exit)
  public double[] whenHitByRay( Triple a, Triple d ) {
    AABB box = new AABB( cx-sx, cx+sx, cy-sy, cy+sy, cz-sz, cz+sz );
    return box.whenHitByRay( a, d );
  }

  public void consoleDisplay() {
    System.out.printf("%s at: %.2f %.2f %.2f" +
                      " sizes: %.2f %.2f %.2f\n",
                  kind, cx, cy, cz, 2*sx, 2*sy, 2*sz ); 
  }
 
  // analyze [al,ar] moving with velocity v against stationary [bl,br],
  // returning -1 if realize can't move toward overlapping, 
  //                 or can't get there within time max,
  //            0 if already significanlty overlapping at time 0 or overlapping slightly and moving inward,
  //            otherwise the time in [0,max] at which the edges are eps apart
  private static double findAxisHitTime( double al, double ar, 
                                         double bl, double br, 
                                         double v, double max ) {

     // System.out.println("findAxisHitTime for [" + al + "," + ar + "] and [" + bl + "," + br + 
       //                "] with v= " + v );

    if( ar < bl - 1.1*eps ) {// A well away from B on the left
      double top = bl - eps - ar;
      if( v >= top / max ) {
        return top / v;     // time until A moves to eps apart from B
      }
      else {// v is too small or negative so can't A won't reach B within max
        return -1;  
      }
    }
    else if( ar <= bl - 0.9*eps ) {// ar within envelope of bl
      if( v <= 0 ) {// barely touching but going away or parallel so will never overlap more
        return -1;
      }
      else {// already barely overlapping and tending to overlap more
        return 0;
      }
    }
    else if( br + 1.1*eps < al ) {// A well away from B on the right
      double top = br+eps-al;
      if( v <= top / max ) {// v negative enough for A to reach B in time
        return top / v;
      }
      else {// v too small or positive 
        return -1;
      }
    }
    else if( br + 0.9*eps < al ) {// barely touching
      if( v >= 0 ) {// and moving apart or parallel
        return -1;
      }
      else {// moving to overlap more
        return 0;
      }
    }
    else {// already overlapping at lambda=0
      return 0;
    }

  }// findAxisHitTime

  // analyze [al,ar] moving with velocity v against stationary [bl,br],
  // returning time when they no longer overlap
  // but returning max+1 if they never overlap or is otherwise meaningless
  private static double findAxisExitTime( double al, double ar, double bl, double br, double v, double max ) {

    // System.out.println("findAxisExitTime on [" + al + "," + ar + "] and [" + bl + "," + br + "] with vel " + v +
      //                    " and time limit " + max );
                         
     if (v >= 0) {// moving to the right or stationary
        if ( al <= br + 1.1*eps ) {// some of A to the left of some of B
           double top = br+1.1*eps-al;
           if ( v >= top / max ) {
              return top / v;
           }
           else {
              return max+1;  
           }
        }
        else {// A entirely to the right of B at time 0
              // and gets farther away
           return 0;
        }
     }
     else {// moving to the left
        if ( ar  >= bl - 1.1*eps ) {// some of A to the right of some of B
           double top = bl - 1.1*eps - ar;
           if ( v <= top / max ) {// v negative enough for B to pass A in time
              return top / v;
           }
           else {// v too small or positive 
              return max+1;
           }
        }
        else {// B entirely to the left of A at time 0
              // and gets farther away
          return 0;
        }
     }

  }// findAxisExitTime

  // return time until block a first hits block b 
  // up to max (if ever realize is going to take longer than max, return -1
  // and if realize will never hit because moving apart or parallel in contact, return -1
  public static double findHitTime( Block a, Block b, double max ) {
 
     // System.out.println("findHitTime with A: " + a + " B: " + b );

    Triple v = a.vel.subtract( b.vel );  // v is relative velocity of a moving toward fixed b
     // System.out.println("initial relative velocity: " + v );
 
    double lambdaEnter;  // time at which overlaps in all three axes

    double lambdaX = findAxisHitTime( a.cx-a.sx, a.cx+a.sx, b.cx-b.sx, b.cx+b.sx, v.x, max );
  
     // System.out.println("x axis hit time: " + lambdaX );

    if( lambdaX == -1 )
      return -1;

    double lambdaY = findAxisHitTime( a.cy-a.sy, a.cy+a.sy, b.cy-b.sy, b.cy+b.sy, v.y, max );
     // System.out.println("y axis hit time: " + lambdaY );
    if( lambdaY == -1 )
      return -1;
    lambdaEnter = Math.max( lambdaX, lambdaY );  // both are either interesting or 0

    double lambdaZ = findAxisHitTime( a.cz-a.sz, a.cz+a.sz, b.cz-b.sz, b.cz+b.sz, v.z, max );
     // System.out.println("z axis hit time: " + lambdaZ );
    if( lambdaZ == -1 )
      return -1;
    lambdaEnter = Math.max( lambdaZ, lambdaEnter );  // both are either interesting or 0

     // System.out.println("maximum axis entry time = " + lambdaEnter );

    // if still here, verify that lambdaEnter is less than the smallest exit time
    double lambdaExitX = findAxisExitTime( a.cx-a.sx, a.cx+a.sx, b.cx-b.sx, b.cx+b.sx, v.x, max );
    double lambdaExitY = findAxisExitTime( a.cy-a.sy, a.cy+a.sy, b.cy-b.sy, b.cy+b.sy, v.y, max );
    double lambdaExitZ = findAxisExitTime( a.cz-a.sz, a.cz+a.sz, b.cz-b.sz, b.cz+b.sz, v.z, max );
    
    // System.out.println("exit times are " + lambdaExitX + " " + lambdaExitY + " " + lambdaExitZ );

    double lambdaExit = Math.min( lambdaExitX, lambdaExitY );
    lambdaExit = Math.min( lambdaExit, lambdaExitZ );

    //  System.out.println("lambdaExit = " + lambdaExit );

    if( lambdaExit < lambdaEnter )
      return -1;
    else
      return lambdaEnter;

  }// findHitTime
 
  public void setVelocity( Triple v ) {
    vel = v;
  }

  public String toString() {
    return kind + ", c: " + cx + " " + cy + " " + cz + " s: " + sx + " " + sy + " " + sz + " vel: " + vel;
  }

  // return fuzzy bounding box for this block
  public AABB getAABB() {
    return new AABB( cx-sx-eps, cx+sx+eps, cy-sy-eps, cy+sy+eps, cz-sz-eps, cz+sz+eps );
  }

  // return AABB that covers this block
  // from now until "time" in the future
  public AABB getSweptAABB( double time ) {
     return new AABB( Math.min( cx-sx-eps, cx-sx-eps + time*vel.x ),
                      Math.max( cx+sx+eps, cx+sx+eps + time*vel.x ),
                      Math.min( cy-sy-eps, cy-sy-eps + time*vel.y ),
                      Math.max( cy+sy+eps, cy+sy+eps + time*vel.y ),
                      Math.min( cz-sz-eps, cz-sz-eps + time*vel.z ),
                      Math.max( cz+sz+eps, cz+sz+eps + time*vel.z ) );
  }

  // return whether this block supports the other block
  // meaning overlap in x-y plane and this.top close to other.bottom
  public boolean supports( Block other ) {
    // give convenient names to x-y plane boundaries of fuzzed blocks
    double l1=cx-sx-eps, r1=cx+sx+eps, n1=cy-sy-eps, f1=cy+sy+eps;
    double l2=other.cx-other.sx-eps, r2=other.cx+other.sx+eps, n2=other.cy-other.sy-eps, f2=other.cy+other.sy+eps;

    double t1 = cz+sz, b2 = other.cz-other.sz;

    // overlap in x and overlap in y and other.bottom touches top
    return !( r1<l2 || r2<l1 ) && !( f1<n2 || f2<n1 ) &&
            t1 < b2 && t1 >= b2-1.1*eps;
  }

  // all blocks have ability, in principle, to do vertical impulse
  // (intended for gravity) but extensions, like Explorer, override
  // because modeling velocity differently
  public void verticalImpulse( double hop ) {
    vel = new Triple( vel.x, vel.y, vel.z+hop );
  }

  public void addRequest( Request r ) {
    requests.add( r );
  }

  // allow all blocks to have own special pending requests
  public void fulfillRequests() {

    // handle all universal requests
    for( int k=0; k<requests.size(); k++ ) {
      Request req = requests.get(k);

      if( req.kind.equals( "gravity" ) ) {
        if( ! supported ) {
          verticalImpulse( Util.gravityAmount );
        }

        requests.remove( k );  // either did it or rejected because supported,
                               // either way, want to remove from list
        k--;  // avoid skipping next one
      }// gravity request

    }// handle request k
  
  }// fulfillRequests

  public void setSupported( boolean status ) {
    supported = status;
  }

  // return whether this block overlaps other
  // (including collision envelope)
  public boolean overlaps( Block other ) {

    // if don't overlap, must be separated in at least one axis

    if( cx+sx + 1.1*eps < other.cx - other.sx ) return false;
    if( other.cx+other.sx + 1.1*eps < cx - sx ) return false;

    if( cy+sy + 1.1*eps < other.cy - other.sy ) return false;
    if( other.cy+other.sy + 1.1*eps < cy - sy ) return false;

    if( cz+sz + 1.1*eps < other.cz - other.sz ) return false;
    if( other.cz+other.sz + 1.1*eps < cz - sz ) return false;

    return true;  // if not separated along any axis, must overlap
  }

  // default behavior is to not retry arrival after notice is no
  // empty space in which to arrive
  // (but some kinds keep trying, like after Explorer goes through Gate
  //  or Door)
  public boolean retriesArrival() {
    return false;
  }

  public int getId() {
     return id;
  }

  // countdown must be set by overriding
  // methods
  protected void becomeGhost() {
     isGhost = true;
  }

  public int getCountdown() {
     return countdown;
  }

  // all blocks have the ability to behave,
  // only Hunter currently does
  public void behave() {
  }

   // determine whether the two blocks have roughly the same base elevation
   // and if so, return orientation from a toward b
   //  [0] is 0 or 1, [1] is the angle, [2] is the distance
   //  --- [1] and [2] not set if [0] is 0
   public static double[] lookToward( Block a, Block b ) { 

System.out.println("lookToward called with A at " + a.cx + " " + a.cy + " " + a.cz +
                    " and B at " + b.cx + " " + b.cy + " " + b.cz );

      double[] result = new double[3];

      if ( b == null ) {
         result[0] = 0;
         return result;
      }

      if ( Math.abs( a.cz - b.cz ) < b.sz ) {// on same level, more or less

System.out.println("on same level");

         result[0] = 1;  // on same level
         double dx = b.cx-a.cx, dy = b.cy-a.cy;
         result[1] = Math.toDegrees( Math.atan2( dy, dx ) );
         result[2] = Math.hypot( dx, dy );

System.out.println("angle is " + result[1] + " and distance is " + result[2] );
       
      }
      else {// not even on the same level
System.out.println("not on same level");
         result[0] = 0;
      }
     
      return result;

   }// lookToward

}// Block
